// src/middleware/rbac.ts
import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { UserRole } from '@prisma/client';
import { hasPermission, Permission } from '@/types/permissions';

type Handler = (
  request: NextRequest,
  context: { params: Record<string, string>; session: any }
) => Promise<NextResponse>;

export function withAuth(handler: Handler): Handler {
  return async (request: NextRequest, context: { params: Record<string, string> }) => {
    try {
      const token = await getToken({ req: request });

      if (!token) {
        return NextResponse.json(
          { error: 'Oturum açmanız gerekiyor' },
          { status: 401 }
        );
      }

      const session = {
        user: {
          id: token.id as string,
          email: token.email as string,
          name: token.name as string,
          role: token.role as UserRole,
          tenantId: token.tenantId as string,
          tenantSlug: token.tenantSlug as string,
          isDemo: token.isDemo as boolean,
        },
      };

      return handler(request, { ...context, session });
    } catch (error) {
      console.error('Auth middleware error:', error);
      return NextResponse.json(
        { error: 'Kimlik doğrulama hatası' },
        { status: 401 }
      );
    }
  };
}

export function withPermission(permission: Permission): (handler: Handler) => Handler {
  return (handler: Handler) => {
    return withAuth(async (request, context) => {
      const { session } = context;

      if (!hasPermission(session.user.role as UserRole, permission)) {
        return NextResponse.json(
          { error: 'Bu işlem için yetkiniz yok' },
          { status: 403 }
        );
      }

      return handler(request, context);
    });
  };
}

export function withAnyPermission(permissions: Permission[]): (handler: Handler) => Handler {
  return (handler: Handler) => {
    return withAuth(async (request, context) => {
      const { session } = context;
      const role = session.user.role as UserRole;

      const hasAny = permissions.some((p) => hasPermission(role, p));

      if (!hasAny) {
        return NextResponse.json(
          { error: 'Bu işlem için yetkiniz yok' },
          { status: 403 }
        );
      }

      return handler(request, context);
    });
  };
}

export function withTenantIsolation<T extends { tenantId: string }>(
  data: T | T[],
  tenantId: string
): T | T[] | null {
  if (Array.isArray(data)) {
    return data.filter((item) => item.tenantId === tenantId);
  }
  
  if (data.tenantId !== tenantId) {
    return null;
  }
  
  return data;
}

export function buildTenantWhereClause(tenantId: string) {
  return { tenantId };
}

export function buildOwnershipWhereClause(
  tenantId: string,
  userId: string,
  role: UserRole,
  ownerField: string = 'assignedToId'
) {
  const baseWhere = { tenantId };

  // Admin and Secretary see all
  if (role === 'ADMIN' || role === 'SECRETARY') {
    return baseWhere;
  }

  // Others see only their own
  return {
    ...baseWhere,
    [ownerField]: userId,
  };
}
