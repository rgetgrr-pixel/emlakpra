// src/middleware/audit.ts
import prisma from '@/lib/prisma';
import { headers } from 'next/headers';

interface AuditLogParams {
  tenantId: string;
  userId?: string;
  action: string;
  entityType: string;
  entityId?: string;
  description?: string;
  oldValue?: Record<string, any>;
  newValue?: Record<string, any>;
  metadata?: Record<string, any>;
}

export async function createAuditLog(params: AuditLogParams): Promise<void> {
  try {
    const headersList = headers();
    const ipAddress = headersList.get('x-forwarded-for')?.split(',')[0] || 
                      headersList.get('x-real-ip') || 
                      'unknown';
    const userAgent = headersList.get('user-agent') || undefined;

    await prisma.auditLog.create({
      data: {
        tenantId: params.tenantId,
        userId: params.userId,
        action: params.action,
        entityType: params.entityType,
        entityId: params.entityId,
        description: params.description,
        oldValue: params.oldValue,
        newValue: params.newValue,
        metadata: params.metadata,
        ipAddress,
        userAgent,
      },
    });
  } catch (error) {
    // Don't throw - audit log failure shouldn't break the main operation
    console.error('Audit log error:', error);
  }
}

export function withAuditLog(
  action: string,
  entityType: string,
  getEntityId?: (result: any) => string
) {
  return function <T extends (...args: any[]) => Promise<any>>(handler: T): T {
    return (async (...args: any[]) => {
      const result = await handler(...args);
      
      // Extract session from args (assuming it's in context)
      const context = args[1];
      if (context?.session?.user) {
        const { tenantId, id: userId } = context.session.user;
        const entityId = getEntityId ? getEntityId(result) : undefined;
        
        await createAuditLog({
          tenantId,
          userId,
          action,
          entityType,
          entityId,
        });
      }
      
      return result;
    }) as T;
  };
}
