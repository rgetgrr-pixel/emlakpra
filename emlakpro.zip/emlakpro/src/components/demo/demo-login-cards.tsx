// src/components/demo/demo-login-cards.tsx
'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DemoUser {
  email: string;
  name: string;
  role: string;
  roleLabel: string;
  description: string;
  permissions: string[];
  color: string;
  emoji: string;
}

const demoUsers: DemoUser[] = [
  {
    email: 'demo_admin@emlakpro.demo',
    name: 'Ahmet Yönetici',
    role: 'ADMIN',
    roleLabel: 'Yönetici',
    description: 'Tüm modüllere tam erişim, kullanıcı ve ayar yönetimi',
    permissions: ['Tüm Modüller', 'Kullanıcı Yönetimi', 'Ayarlar', 'Raporlar', 'KVKK'],
    color: 'bg-red-500',
    emoji: '👔',
  },
  {
    email: 'demo_secretary@emlakpro.demo',
    name: 'Ayşe Sekreter',
    role: 'SECRETARY',
    roleLabel: 'Sekreter',
    description: 'Operasyonel işlemler, lead atama, randevu yönetimi',
    permissions: ['Lead Yönetimi', 'Randevu', 'İlan Yönetimi', 'Sözleşmeler', 'Import'],
    color: 'bg-purple-500',
    emoji: '👩‍💼',
  },
  {
    email: 'demo_agent@emlakpro.demo',
    name: 'Mehmet Danışman',
    role: 'AGENT',
    roleLabel: 'Emlak Danışmanı',
    description: 'Kendi leadleri ve dosyaları, ilan oluşturma, AI araçları',
    permissions: ['Kendi Leadleri', 'Kendi Dosyaları', 'İlan Ekleme', 'AI Stüdyo', 'Drone'],
    color: 'bg-blue-500',
    emoji: '🏠',
  },
  {
    email: 'demo_field@emlakpro.demo',
    name: 'Ali Saha',
    role: 'FIELD',
    roleLabel: 'Saha Personeli',
    description: 'Gösterim check-in/out, lokasyon bazlı görevler',
    permissions: ['Gösterimler', 'Check-in/Out', 'Fotoğraf Yükleme'],
    color: 'bg-green-500',
    emoji: '🚗',
  },
  {
    email: 'demo_client@emlakpro.demo',
    name: 'Fatma Müşteri',
    role: 'CLIENT',
    roleLabel: 'Müşteri Portal',
    description: 'Kendi dosyalarını görüntüleme, paylaşılan belgeler',
    permissions: ['Kendi Dosyaları', 'Paylaşılan Belgeler', 'Bildirimler'],
    color: 'bg-orange-500',
    emoji: '👤',
  },
];

export function DemoLoginCards() {
  const router = useRouter();
  const [loadingEmail, setLoadingEmail] = useState<string | null>(null);

  const handleDemoLogin = async (email: string) => {
    setLoadingEmail(email);
    try {
      const result = await signIn('credentials', {
        email,
        password: 'demo123',
        redirect: false,
      });

      if (result?.error) {
        console.error('Demo login error:', result.error);
        alert('Giriş başarısız. Lütfen tekrar deneyin.');
      } else {
        router.push('/dashboard');
      }
    } catch (error) {
      console.error('Demo login error:', error);
      alert('Bir hata oluştu.');
    } finally {
      setLoadingEmail(null);
    }
  };

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
      {demoUsers.map((user) => (
        <Card
          key={user.email}
          className={cn(
            'relative overflow-hidden transition-all hover:shadow-lg cursor-pointer',
            loadingEmail === user.email && 'ring-2 ring-primary'
          )}
          onClick={() => handleDemoLogin(user.email)}
        >
          {/* Color Bar */}
          <div className={cn('h-2', user.color)} />

          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{user.emoji}</span>
              <div>
                <CardTitle className="text-base">{user.name}</CardTitle>
                <Badge variant="secondary" className="mt-1">
                  {user.roleLabel}
                </Badge>
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            <CardDescription className="text-sm">
              {user.description}
            </CardDescription>

            <div className="flex flex-wrap gap-1">
              {user.permissions.slice(0, 3).map((perm) => (
                <Badge key={perm} variant="outline" className="text-xs">
                  {perm}
                </Badge>
              ))}
              {user.permissions.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{user.permissions.length - 3}
                </Badge>
              )}
            </div>

            <Button
              className="w-full"
              disabled={loadingEmail !== null}
              onClick={(e) => {
                e.stopPropagation();
                handleDemoLogin(user.email);
              }}
            >
              {loadingEmail === user.email ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Giriş yapılıyor...
                </>
              ) : (
                'Giriş Yap'
              )}
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
