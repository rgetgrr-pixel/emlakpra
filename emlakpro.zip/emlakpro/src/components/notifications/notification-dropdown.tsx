// src/components/notifications/notification-dropdown.tsx
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Bell, Check, CheckCheck, Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { formatRelativeTime } from '@/lib/utils';
import { playNotificationSound, setNotificationSoundEnabled } from '@/lib/notifications/sound';
import { cn } from '@/lib/utils';

interface Notification {
  id: string;
  type: string;
  title: string;
  body: string;
  actionUrl?: string;
  isRead: boolean;
  playSound: boolean;
  createdAt: string;
}

export function NotificationDropdown() {
  const [isOpen, setIsOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [lastNotificationId, setLastNotificationId] = useState<string | null>(null);
  const queryClient = useQueryClient();

  // Fetch notifications
  const { data: notifications = [], isLoading } = useQuery<Notification[]>({
    queryKey: ['notifications'],
    queryFn: async () => {
      const res = await fetch('/api/notifications?limit=20');
      if (!res.ok) throw new Error('Failed to fetch');
      return res.json();
    },
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  // Play sound when new notification arrives
  useEffect(() => {
    if (notifications.length > 0 && notifications[0].id !== lastNotificationId) {
      const latestNotification = notifications[0];
      if (!latestNotification.isRead && latestNotification.playSound && soundEnabled) {
        playNotificationSound();
      }
      setLastNotificationId(latestNotification.id);
    }
  }, [notifications, lastNotificationId, soundEnabled]);

  // Mark as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      const res = await fetch(`/api/notifications/${notificationId}/read`, {
        method: 'PATCH',
      });
      if (!res.ok) throw new Error('Failed to mark as read');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  // Mark all as read mutation
  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch('/api/notifications/read-all', {
        method: 'PATCH',
      });
      if (!res.ok) throw new Error('Failed to mark all as read');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.isRead) {
      markAsReadMutation.mutate(notification.id);
    }
    setIsOpen(false);
  };

  const toggleSound = () => {
    const newValue = !soundEnabled;
    setSoundEnabled(newValue);
    setNotificationSoundEnabled(newValue);
    if (newValue) {
      playNotificationSound();
    }
  };

  const getNotificationIcon = (type: string) => {
    const icons: Record<string, string> = {
      NEW_LEAD: '🎯',
      LEAD_ASSIGNED: '📋',
      TASK_ASSIGNED: '📝',
      TASK_DUE: '⏰',
      APPOINTMENT_REMINDER: '📅',
      SHOWING_REMINDER: '🏠',
      CASEFILE_UPDATE: '📁',
      VIDEO_COMPLETED: '🎬',
      DRONE_ORDER_UPDATE: '🚁',
      SYNC_COMPLETED: '🔄',
      SYSTEM: '⚙️',
    };
    return icons[type] || '📣';
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge
              variant="destructive"
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </Badge>
          )}
          <span className="sr-only">Bildirimler</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-full sm:w-96 p-0">
        <SheetHeader className="p-4 border-b">
          <div className="flex items-center justify-between">
            <SheetTitle>Bildirimler</SheetTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleSound}
                title={soundEnabled ? 'Sesi kapat' : 'Sesi aç'}
              >
                {soundEnabled ? (
                  <Volume2 className="h-4 w-4" />
                ) : (
                  <VolumeX className="h-4 w-4" />
                )}
              </Button>
              {unreadCount > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => markAllAsReadMutation.mutate()}
                  disabled={markAllAsReadMutation.isPending}
                >
                  <CheckCheck className="h-4 w-4 mr-1" />
                  Tümünü Oku
                </Button>
              )}
            </div>
          </div>
        </SheetHeader>

        <div className="overflow-y-auto h-[calc(100vh-80px)]">
          {isLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full" />
            </div>
          ) : notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
              <Bell className="h-8 w-8 mb-2" />
              <p>Bildirim yok</p>
            </div>
          ) : (
            <ul className="divide-y">
              {notifications.map((notification) => (
                <li key={notification.id}>
                  {notification.actionUrl ? (
                    <Link
                      href={notification.actionUrl}
                      onClick={() => handleNotificationClick(notification)}
                      className={cn(
                        'block px-4 py-3 hover:bg-muted transition-colors',
                        !notification.isRead && 'bg-primary/5'
                      )}
                    >
                      <NotificationItem notification={notification} />
                    </Link>
                  ) : (
                    <div
                      className={cn(
                        'px-4 py-3',
                        !notification.isRead && 'bg-primary/5'
                      )}
                    >
                      <NotificationItem notification={notification} />
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

function NotificationItem({ notification }: { notification: Notification }) {
  const getNotificationIcon = (type: string) => {
    const icons: Record<string, string> = {
      NEW_LEAD: '🎯',
      LEAD_ASSIGNED: '📋',
      TASK_ASSIGNED: '📝',
      TASK_DUE: '⏰',
      APPOINTMENT_REMINDER: '📅',
      SHOWING_REMINDER: '🏠',
      CASEFILE_UPDATE: '📁',
      VIDEO_COMPLETED: '🎬',
      DRONE_ORDER_UPDATE: '🚁',
      SYNC_COMPLETED: '🔄',
      SYSTEM: '⚙️',
    };
    return icons[type] || '📣';
  };

  return (
    <div className="flex gap-3">
      <span className="text-xl flex-shrink-0">
        {getNotificationIcon(notification.type)}
      </span>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium line-clamp-1">{notification.title}</p>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {notification.body}
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          {formatRelativeTime(notification.createdAt)}
        </p>
      </div>
      {!notification.isRead && (
        <div className="h-2 w-2 bg-primary rounded-full flex-shrink-0 mt-2" />
      )}
    </div>
  );
}
