// src/components/layout/fab-button.tsx
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Plus, X, Phone, Building2, FolderPlus, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';
import { hasPermission } from '@/types/permissions';
import { UserRole } from '@prisma/client';

interface FabItem {
  label: string;
  icon: React.ElementType;
  href: string;
  permission?: string;
  color?: string;
}

const fabItems: FabItem[] = [
  {
    label: 'Yeni Lead',
    icon: Phone,
    href: '/leadler/yeni',
    permission: 'leads:create',
    color: 'bg-blue-500',
  },
  {
    label: 'Yeni İlan',
    icon: Building2,
    href: '/portfoy/yeni',
    permission: 'listings:create',
    color: 'bg-green-500',
  },
  {
    label: 'Yeni Dosya',
    icon: FolderPlus,
    href: '/dosyalar/yeni',
    permission: 'casefiles:create',
    color: 'bg-purple-500',
  },
  {
    label: 'Yeni Randevu',
    icon: Calendar,
    href: '/takvim/yeni',
    permission: 'activities:create',
    color: 'bg-orange-500',
  },
];

export function FabButton() {
  const [isOpen, setIsOpen] = useState(false);
  const router = useRouter();
  const { data: session } = useSession();

  const role = (session?.user?.role as UserRole) || 'AGENT';

  // Filter items based on permissions
  const allowedItems = fabItems.filter((item) => {
    if (!item.permission) return true;
    return hasPermission(role, item.permission as any);
  });

  // Don't show FAB for roles with no create permissions
  if (allowedItems.length === 0) return null;

  const handleItemClick = (href: string) => {
    setIsOpen(false);
    router.push(href);
  };

  return (
    <div className="lg:hidden">
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/20 z-40"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* FAB Menu Items */}
      <div
        className={cn(
          'fixed bottom-20 right-4 z-50 flex flex-col-reverse gap-3 transition-all duration-300',
          isOpen
            ? 'opacity-100 translate-y-0'
            : 'opacity-0 translate-y-4 pointer-events-none'
        )}
      >
        {allowedItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <button
              key={item.href}
              onClick={() => handleItemClick(item.href)}
              className={cn(
                'flex items-center gap-3 pl-4 pr-5 py-2.5 rounded-full shadow-lg',
                'bg-card border text-card-foreground',
                'transition-all duration-300 hover:scale-105',
                'animate-slide-up'
              )}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div
                className={cn(
                  'h-8 w-8 rounded-full flex items-center justify-center',
                  item.color || 'bg-primary',
                  'text-white'
                )}
              >
                <Icon className="h-4 w-4" />
              </div>
              <span className="text-sm font-medium whitespace-nowrap">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* FAB Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          'fixed bottom-20 right-4 z-50',
          'h-14 w-14 rounded-full shadow-lg',
          'flex items-center justify-center',
          'transition-all duration-300',
          isOpen
            ? 'bg-muted text-muted-foreground rotate-45'
            : 'bg-primary text-primary-foreground animate-pulse-ring'
        )}
      >
        {isOpen ? <X className="h-6 w-6" /> : <Plus className="h-6 w-6" />}
      </button>
    </div>
  );
}
