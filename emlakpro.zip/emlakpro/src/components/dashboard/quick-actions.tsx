// src/components/dashboard/quick-actions.tsx
'use client';

import Link from 'next/link';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Phone, 
  Building2, 
  FolderPlus, 
  Calendar, 
  Upload,
  Sparkles,
  Plane,
  Map
} from 'lucide-react';
import { hasPermission } from '@/types/permissions';
import { UserRole } from '@prisma/client';
import { cn } from '@/lib/utils';

interface QuickAction {
  title: string;
  description: string;
  href: string;
  icon: React.ElementType;
  permission?: string;
  color: string;
}

const quickActions: QuickAction[] = [
  {
    title: 'Yeni Lead',
    description: 'Potansiyel müşteri ekle',
    href: '/leadler/yeni',
    icon: Phone,
    permission: 'leads:create',
    color: 'bg-blue-500',
  },
  {
    title: 'Yeni İlan',
    description: 'Portföye ilan ekle',
    href: '/portfoy/yeni',
    icon: Building2,
    permission: 'listings:create',
    color: 'bg-green-500',
  },
  {
    title: 'Yeni Dosya',
    description: 'İşlem dosyası aç',
    href: '/dosyalar/yeni',
    icon: FolderPlus,
    permission: 'casefiles:create',
    color: 'bg-purple-500',
  },
  {
    title: 'Randevu',
    description: 'Randevu oluştur',
    href: '/takvim/yeni',
    icon: Calendar,
    permission: 'activities:create',
    color: 'bg-orange-500',
  },
  {
    title: 'İlan İmport',
    description: 'CSV/XML ile aktar',
    href: '/portfoy/import',
    icon: Upload,
    permission: 'integrations:import',
    color: 'bg-indigo-500',
  },
  {
    title: 'AI Stüdyo',
    description: 'İçerik üret',
    href: '/ai-studyo',
    icon: Sparkles,
    permission: 'ai:content',
    color: 'bg-pink-500',
  },
  {
    title: 'Drone Çekim',
    description: 'Hava çekimi sipariş',
    href: '/drone/yeni',
    icon: Plane,
    permission: 'drone:create',
    color: 'bg-cyan-500',
  },
  {
    title: 'Ada-Parsel',
    description: 'Tapu sorgula',
    href: '/ada-parsel',
    icon: Map,
    permission: 'ai:parcel',
    color: 'bg-teal-500',
  },
];

export function QuickActions() {
  const { data: session } = useSession();
  const role = (session?.user?.role as UserRole) || 'AGENT';

  const allowedActions = quickActions.filter((action) => {
    if (!action.permission) return true;
    return hasPermission(role, action.permission as any);
  });

  if (allowedActions.length === 0) return null;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">Hızlı İşlemler</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {allowedActions.slice(0, 8).map((action) => {
            const Icon = action.icon;
            return (
              <Link key={action.href} href={action.href}>
                <Button
                  variant="outline"
                  className="w-full h-auto flex flex-col items-center gap-2 p-4 hover:bg-muted"
                >
                  <div
                    className={cn(
                      'h-10 w-10 rounded-full flex items-center justify-center',
                      action.color,
                      'text-white'
                    )}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="text-center">
                    <p className="font-medium text-sm">{action.title}</p>
                    <p className="text-xs text-muted-foreground hidden sm:block">
                      {action.description}
                    </p>
                  </div>
                </Button>
              </Link>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
