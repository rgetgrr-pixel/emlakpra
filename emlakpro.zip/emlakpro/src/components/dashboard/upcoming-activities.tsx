// src/components/dashboard/upcoming-activities.tsx
import Link from 'next/link';
import { getSession } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, ArrowRight, Clock, Phone, Users, MapPin, CheckSquare } from 'lucide-react';
import { formatDate, formatDateTime, cn } from '@/lib/utils';

const activityIcons: Record<string, React.ElementType> = {
  CALL: Phone,
  MEETING: Users,
  APPOINTMENT: Calendar,
  SHOWING: MapPin,
  TASK: CheckSquare,
  FOLLOW_UP: Clock,
};

const priorityColors: Record<string, string> = {
  URGENT: 'bg-red-100 text-red-800 border-red-200',
  HIGH: 'bg-orange-100 text-orange-800 border-orange-200',
  MEDIUM: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  LOW: 'bg-gray-100 text-gray-800 border-gray-200',
};

async function getUpcomingActivities(tenantId: string, userId: string) {
  const now = new Date();
  const endOfWeek = new Date(now);
  endOfWeek.setDate(endOfWeek.getDate() + 7);

  return prisma.activity.findMany({
    where: {
      tenantId,
      status: 'PENDING',
      startAt: {
        gte: now,
        lte: endOfWeek,
      },
    },
    orderBy: { startAt: 'asc' },
    take: 5,
    include: {
      lead: {
        select: { name: true, phone: true },
      },
      caseFile: {
        select: { refNumber: true },
      },
    },
  });
}

export async function UpcomingActivities() {
  const session = await getSession();
  if (!session?.user?.tenantId) return null;

  const activities = await getUpcomingActivities(
    session.user.tenantId,
    session.user.id
  );

  const isToday = (date: Date) => {
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

  const isTomorrow = (date: Date) => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return (
      date.getDate() === tomorrow.getDate() &&
      date.getMonth() === tomorrow.getMonth() &&
      date.getFullYear() === tomorrow.getFullYear()
    );
  };

  const getDateLabel = (date: Date) => {
    if (isToday(date)) return 'Bugün';
    if (isTomorrow(date)) return 'Yarın';
    return formatDate(date, 'dd MMM');
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold">Yaklaşan Aktiviteler</CardTitle>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/takvim">
            Tümü
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent>
        {activities.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Calendar className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>Yaklaşan aktivite yok</p>
          </div>
        ) : (
          <ul className="space-y-3">
            {activities.map((activity) => {
              const Icon = activityIcons[activity.type] || Calendar;
              const startAt = new Date(activity.startAt);
              const dateLabel = getDateLabel(startAt);

              return (
                <li key={activity.id}>
                  <Link
                    href={`/gorevler/${activity.id}`}
                    className={cn(
                      'flex items-start gap-3 p-3 rounded-lg border transition-colors',
                      'hover:bg-muted',
                      priorityColors[activity.priority]
                    )}
                  >
                    <div className="flex-shrink-0 mt-0.5">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium line-clamp-1">{activity.title}</p>
                      <div className="flex items-center gap-2 mt-1 text-sm">
                        <span className="font-medium">{dateLabel}</span>
                        <span>•</span>
                        <span>
                          {startAt.toLocaleTimeString('tr-TR', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      {activity.lead && (
                        <p className="text-sm text-muted-foreground mt-1 truncate">
                          {activity.lead.name || activity.lead.phone}
                        </p>
                      )}
                      {activity.caseFile && (
                        <p className="text-sm text-muted-foreground mt-1">
                          Dosya: {activity.caseFile.refNumber}
                        </p>
                      )}
                    </div>
                    {activity.priority === 'URGENT' && (
                      <Badge variant="destructive" className="text-xs">
                        Acil
                      </Badge>
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
