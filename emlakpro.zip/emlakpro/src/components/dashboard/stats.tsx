// src/components/dashboard/stats.tsx
import { getSession } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { Card, CardContent } from '@/components/ui/card';
import { Phone, Building2, FolderKanban, Calendar, TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '@/lib/utils';

async function getStats(tenantId: string) {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);

  const [
    leadsCount,
    leadsLastMonth,
    activeListings,
    listingsLastMonth,
    openCaseFiles,
    todayActivities,
  ] = await Promise.all([
    // This month's leads
    prisma.lead.count({
      where: { tenantId, createdAt: { gte: startOfMonth } },
    }),
    // Last month's leads
    prisma.lead.count({
      where: {
        tenantId,
        createdAt: { gte: startOfLastMonth, lte: endOfLastMonth },
      },
    }),
    // Active listings
    prisma.listing.count({
      where: { tenantId, status: 'ACTIVE' },
    }),
    // Last month active listings (approximation)
    prisma.listing.count({
      where: {
        tenantId,
        status: 'ACTIVE',
        createdAt: { lte: endOfLastMonth },
      },
    }),
    // Open case files
    prisma.caseFile.count({
      where: {
        tenantId,
        status: { notIn: ['COMPLETED', 'CANCELLED'] },
      },
    }),
    // Today's activities
    prisma.activity.count({
      where: {
        tenantId,
        startAt: {
          gte: new Date(now.setHours(0, 0, 0, 0)),
          lt: new Date(now.setHours(23, 59, 59, 999)),
        },
      },
    }),
  ]);

  return {
    leads: {
      count: leadsCount,
      change: leadsLastMonth > 0 
        ? Math.round(((leadsCount - leadsLastMonth) / leadsLastMonth) * 100)
        : 0,
    },
    listings: {
      count: activeListings,
      change: listingsLastMonth > 0
        ? Math.round(((activeListings - listingsLastMonth) / listingsLastMonth) * 100)
        : 0,
    },
    caseFiles: {
      count: openCaseFiles,
    },
    activities: {
      count: todayActivities,
    },
  };
}

export async function DashboardStats() {
  const session = await getSession();
  if (!session?.user?.tenantId) return null;

  const stats = await getStats(session.user.tenantId);

  const statCards = [
    {
      title: 'Bu Ay Lead',
      value: stats.leads.count,
      change: stats.leads.change,
      icon: Phone,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10',
    },
    {
      title: 'Aktif İlan',
      value: stats.listings.count,
      change: stats.listings.change,
      icon: Building2,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10',
    },
    {
      title: 'Açık Dosya',
      value: stats.caseFiles.count,
      icon: FolderKanban,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10',
    },
    {
      title: 'Bugün Aktivite',
      value: stats.activities.count,
      icon: Calendar,
      color: 'text-orange-500',
      bgColor: 'bg-orange-500/10',
    },
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {statCards.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.title} className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-3xl font-bold mt-1">{stat.value}</p>
                  {stat.change !== undefined && (
                    <div
                      className={cn(
                        'flex items-center gap-1 text-sm mt-1',
                        stat.change >= 0 ? 'text-green-600' : 'text-red-600'
                      )}
                    >
                      {stat.change >= 0 ? (
                        <TrendingUp className="h-4 w-4" />
                      ) : (
                        <TrendingDown className="h-4 w-4" />
                      )}
                      <span>{Math.abs(stat.change)}%</span>
                      <span className="text-muted-foreground">geçen aya göre</span>
                    </div>
                  )}
                </div>
                <div className={cn('p-3 rounded-full', stat.bgColor)}>
                  <Icon className={cn('h-6 w-6', stat.color)} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
