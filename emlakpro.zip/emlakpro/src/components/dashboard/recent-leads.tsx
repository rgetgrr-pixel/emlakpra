// src/components/dashboard/recent-leads.tsx
import Link from 'next/link';
import { getSession } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Phone, ArrowRight } from 'lucide-react';
import { formatRelativeTime, getInitials, formatPhone } from '@/lib/utils';
import { cn } from '@/lib/utils';

const statusColors: Record<string, string> = {
  NEW: 'bg-blue-100 text-blue-800',
  CONTACTED: 'bg-yellow-100 text-yellow-800',
  QUALIFIED: 'bg-purple-100 text-purple-800',
  MEETING_SCHEDULED: 'bg-indigo-100 text-indigo-800',
  NEGOTIATION: 'bg-orange-100 text-orange-800',
  CONVERTED: 'bg-green-100 text-green-800',
  LOST: 'bg-red-100 text-red-800',
};

const statusLabels: Record<string, string> = {
  NEW: 'Yeni',
  CONTACTED: 'İletişime Geçildi',
  QUALIFIED: 'Nitelikli',
  MEETING_SCHEDULED: 'Randevu Alındı',
  NEGOTIATION: 'Görüşme',
  CONVERTED: 'Dönüştürüldü',
  LOST: 'Kaybedildi',
};

const temperatureColors: Record<string, string> = {
  HOT: 'bg-red-500',
  WARM: 'bg-orange-500',
  COLD: 'bg-blue-500',
};

async function getRecentLeads(tenantId: string) {
  return prisma.lead.findMany({
    where: { tenantId },
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: {
      assignedTo: {
        select: { name: true },
      },
    },
  });
}

export async function RecentLeads() {
  const session = await getSession();
  if (!session?.user?.tenantId) return null;

  const leads = await getRecentLeads(session.user.tenantId);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold">Son Leadler</CardTitle>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/leadler">
            Tümü
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent>
        {leads.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Phone className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>Henüz lead yok</p>
          </div>
        ) : (
          <ul className="space-y-3">
            {leads.map((lead) => (
              <li key={lead.id}>
                <Link
                  href={`/leadler/${lead.id}`}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors"
                >
                  <Avatar className="h-10 w-10">
                    <AvatarFallback>
                      {lead.name ? getInitials(lead.name) : '?'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium truncate">
                        {lead.name || formatPhone(lead.phone)}
                      </p>
                      <div
                        className={cn(
                          'h-2 w-2 rounded-full',
                          temperatureColors[lead.temperature]
                        )}
                        title={lead.temperature}
                      />
                    </div>
                    <p className="text-sm text-muted-foreground truncate">
                      {lead.source} • {formatRelativeTime(lead.createdAt)}
                    </p>
                  </div>
                  <Badge
                    className={cn(
                      'text-xs',
                      statusColors[lead.status]
                    )}
                  >
                    {statusLabels[lead.status]}
                  </Badge>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
