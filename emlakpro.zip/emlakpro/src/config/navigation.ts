// src/config/navigation.ts
import {
  LayoutDashboard,
  Users,
  Building2,
  FolderKanban,
  Calendar,
  CheckSquare,
  MapPin,
  FileText,
  FileSignature,
  Sparkles,
  Map,
  Plane,
  BarChart3,
  Bell,
  Settings,
  User,
  Phone,
  Heart,
  Handshake,
  type LucideIcon,
} from 'lucide-react';
import { UserRole } from '@prisma/client';

export interface NavItem {
  title: string;
  href: string;
  icon: LucideIcon;
  badge?: string;
  roles?: UserRole[];
  children?: NavItem[];
}

export const mainNavItems: NavItem[] = [
  {
    title: 'Dashboard',
    href: '/dashboard',
    icon: LayoutDashboard,
  },
  {
    title: 'Leadler',
    href: '/leadler',
    icon: Phone,
    roles: ['ADMIN', 'SECRETARY', 'AGENT'],
  },
  {
    title: 'Kişiler',
    href: '/kisiler',
    icon: Users,
    roles: ['ADMIN', 'SECRETARY', 'AGENT'],
  },
  {
    title: 'Portföy',
    href: '/portfoy',
    icon: Building2,
    roles: ['ADMIN', 'SECRETARY', 'AGENT', 'FIELD'],
  },
  {
    title: 'Talepler',
    href: '/talepler',
    icon: Heart,
    roles: ['ADMIN', 'SECRETARY', 'AGENT'],
  },
  {
    title: 'Eşleştirme',
    href: '/eslestirme',
    icon: Handshake,
    roles: ['ADMIN', 'SECRETARY', 'AGENT'],
  },
  {
    title: 'Dosyalar',
    href: '/dosyalar',
    icon: FolderKanban,
  },
  {
    title: 'Takvim',
    href: '/takvim',
    icon: Calendar,
  },
  {
    title: 'Görevler',
    href: '/gorevler',
    icon: CheckSquare,
    roles: ['ADMIN', 'SECRETARY', 'AGENT'],
  },
  {
    title: 'Gösterimler',
    href: '/gosterimler',
    icon: MapPin,
    roles: ['ADMIN', 'SECRETARY', 'AGENT', 'FIELD'],
  },
  {
    title: 'Belgeler',
    href: '/belgeler',
    icon: FileText,
  },
  {
    title: 'Sözleşmeler',
    href: '/sozlesmeler',
    icon: FileSignature,
    roles: ['ADMIN', 'SECRETARY', 'AGENT'],
  },
  {
    title: 'AI Stüdyo',
    href: '/ai-studyo',
    icon: Sparkles,
    roles: ['ADMIN', 'SECRETARY', 'AGENT'],
    children: [
      { title: 'İçerik Üretici', href: '/ai-studyo/icerik', icon: FileText },
      { title: 'Video Stüdyo', href: '/ai-studyo/video', icon: Sparkles },
    ],
  },
  {
    title: 'Ada-Parsel',
    href: '/ada-parsel',
    icon: Map,
    roles: ['ADMIN', 'SECRETARY', 'AGENT'],
  },
  {
    title: 'Drone Çekim',
    href: '/drone',
    icon: Plane,
    roles: ['ADMIN', 'SECRETARY', 'AGENT'],
  },
  {
    title: 'Raporlar',
    href: '/raporlar',
    icon: BarChart3,
    roles: ['ADMIN', 'SECRETARY', 'AGENT'],
  },
];

export const bottomNavItems: NavItem[] = [
  {
    title: 'Bildirimler',
    href: '/bildirimler',
    icon: Bell,
  },
  {
    title: 'Ayarlar',
    href: '/ayarlar',
    icon: Settings,
    roles: ['ADMIN', 'SECRETARY'],
  },
  {
    title: 'Profil',
    href: '/profil',
    icon: User,
  },
];

export const mobileNavItems: NavItem[] = [
  {
    title: 'Ana Sayfa',
    href: '/dashboard',
    icon: LayoutDashboard,
  },
  {
    title: 'Lead',
    href: '/leadler',
    icon: Phone,
  },
  {
    title: 'Dosya',
    href: '/dosyalar',
    icon: FolderKanban,
  },
  {
    title: 'Takvim',
    href: '/takvim',
    icon: Calendar,
  },
];

export const clientNavItems: NavItem[] = [
  {
    title: 'Dashboard',
    href: '/portal',
    icon: LayoutDashboard,
  },
  {
    title: 'Dosyalarım',
    href: '/portal/dosyalar',
    icon: FolderKanban,
  },
  {
    title: 'Belgeler',
    href: '/portal/belgeler',
    icon: FileText,
  },
  {
    title: 'Bildirimler',
    href: '/portal/bildirimler',
    icon: Bell,
  },
];

export function getNavItemsForRole(role: UserRole): NavItem[] {
  if (role === 'CLIENT') {
    return clientNavItems;
  }

  return mainNavItems.filter((item) => {
    if (!item.roles) return true;
    return item.roles.includes(role);
  });
}

export function getMobileNavItemsForRole(role: UserRole): NavItem[] {
  if (role === 'CLIENT') {
    return clientNavItems.slice(0, 4);
  }

  if (role === 'FIELD') {
    return [
      { title: 'Ana Sayfa', href: '/dashboard', icon: LayoutDashboard },
      { title: 'Gösterim', href: '/gosterimler', icon: MapPin },
      { title: 'Portföy', href: '/portfoy', icon: Building2 },
      { title: 'Takvim', href: '/takvim', icon: Calendar },
    ];
  }

  return mobileNavItems;
}
