// src/config/site.ts

export const siteConfig = {
  name: 'EmlakPro',
  description: 'Emlak ofisleri için kapsamlı B2B SaaS CRM çözümü',
  url: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
  ogImage: '/og-image.png',
  
  contact: {
    phone: '0850 000 0000',
    email: 'destek@emlakpro.com',
    address: 'İstanbul, Türkiye',
  },
  
  social: {
    twitter: 'https://twitter.com/emlakpro',
    linkedin: 'https://linkedin.com/company/emlakpro',
    instagram: 'https://instagram.com/emlakpro',
  },
  
  features: [
    {
      title: 'Emlak CRM',
      description: 'Lead ve müşteri yönetimi, pipeline görünümü',
      icon: 'users',
    },
    {
      title: 'Portföy Yönetimi',
      description: 'İlan yönetimi, Sahibinden entegrasyonu',
      icon: 'building',
    },
    {
      title: 'Dosya Sistemi',
      description: 'Her işlem için tek dosya, timeline görünümü',
      icon: 'folder',
    },
    {
      title: 'AI İçerik Stüdyosu',
      description: 'İlan metni, broşür, sosyal medya içeriği',
      icon: 'sparkles',
    },
    {
      title: 'AI Video Stüdyosu',
      description: '4 görsel ile tanıtım videosu',
      icon: 'video',
    },
    {
      title: 'Drone Çekim',
      description: 'Profesyonel hava çekimi sipariş',
      icon: 'plane',
    },
  ],
  
  plans: [
    {
      name: 'Starter',
      price: 499,
      description: 'Küçük ofisler için',
      features: [
        '3 kullanıcı',
        '500 ilan',
        'CRM modülü',
        'Email desteği',
      ],
    },
    {
      name: 'Professional',
      price: 999,
      description: 'Büyüyen ofisler için',
      features: [
        '10 kullanıcı',
        'Sınırsız ilan',
        'Tüm modüller',
        'Sahibinden entegrasyonu',
        'AI özellikleri',
        'Öncelikli destek',
      ],
      popular: true,
    },
    {
      name: 'Enterprise',
      price: 'Özel',
      description: 'Büyük firmalar için',
      features: [
        'Sınırsız kullanıcı',
        'Sınırsız ilan',
        'Tüm modüller',
        'Özel entegrasyonlar',
        'Özel eğitim',
        '7/24 destek',
        'SLA garantisi',
      ],
    },
  ],
};

export type SiteConfig = typeof siteConfig;
