// src/lib/validations.ts
import { z } from 'zod';

// ============================================================================
// AUTH
// ============================================================================

export const loginSchema = z.object({
  email: z.string().email('Geçerli bir email adresi girin'),
  password: z.string().min(6, 'Şifre en az 6 karakter olmalı'),
});

export const registerSchema = z.object({
  name: z.string().min(2, 'İsim en az 2 karakter olmalı'),
  email: z.string().email('Geçerli bir email adresi girin'),
  phone: z.string().min(10, 'Geçerli bir telefon numarası girin'),
  password: z.string().min(6, 'Şifre en az 6 karakter olmalı'),
  tenantName: z.string().min(2, 'Firma adı en az 2 karakter olmalı'),
});

// ============================================================================
// CONTACT
// ============================================================================

export const contactSchema = z.object({
  type: z.enum(['INDIVIDUAL', 'COMPANY']).default('INDIVIDUAL'),
  firstName: z.string().min(1, 'Ad zorunlu'),
  lastName: z.string().min(1, 'Soyad zorunlu'),
  companyName: z.string().optional(),
  taxNumber: z.string().optional(),
  phone: z.string().min(10, 'Geçerli bir telefon numarası girin'),
  email: z.string().email().optional().or(z.literal('')),
  city: z.string().optional(),
  district: z.string().optional(),
  address: z.string().optional(),
  source: z.string().optional(),
  kvkkConsent: z.boolean().default(false),
  marketingConsent: z.boolean().default(false),
  notes: z.string().optional(),
  tags: z.array(z.string()).default([]),
});

// ============================================================================
// LEAD
// ============================================================================

export const leadSchema = z.object({
  phone: z.string().min(10, 'Geçerli bir telefon numarası girin'),
  name: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  status: z.enum(['NEW', 'CONTACTED', 'QUALIFIED', 'MEETING_SCHEDULED', 'NEGOTIATION', 'CONVERTED', 'LOST']).default('NEW'),
  source: z.enum(['SAHIBINDEN', 'WEBSITE', 'REFERRAL', 'PHONE', 'WALKIN', 'SOCIAL_MEDIA', 'MANUAL', 'OTHER']).default('MANUAL'),
  sourceDetail: z.string().optional(),
  interestType: z.enum(['BUY', 'SELL', 'RENT_TENANT', 'RENT_LANDLORD']).optional(),
  budget: z.number().positive().optional(),
  budgetMax: z.number().positive().optional(),
  preferredCity: z.string().optional(),
  preferredDistrict: z.string().optional(),
  preferredRooms: z.string().optional(),
  temperature: z.enum(['HOT', 'WARM', 'COLD']).default('WARM'),
  notes: z.string().optional(),
  assignedToId: z.string().optional(),
});

// ============================================================================
// LISTING
// ============================================================================

export const listingSchema = z.object({
  title: z.string().min(5, 'Başlık en az 5 karakter olmalı'),
  description: z.string().optional(),
  type: z.enum(['APARTMENT', 'VILLA', 'RESIDENCE', 'OFFICE', 'SHOP', 'LAND', 'BUILDING', 'WAREHOUSE', 'OTHER']),
  status: z.enum(['DRAFT', 'ACTIVE', 'RESERVED', 'SOLD', 'RENTED', 'ARCHIVED']).default('DRAFT'),
  transactionType: z.enum(['SALE', 'RENT']),
  price: z.number().positive('Fiyat pozitif olmalı'),
  currency: z.string().default('TRY'),
  city: z.string().min(1, 'İl zorunlu'),
  district: z.string().min(1, 'İlçe zorunlu'),
  neighborhood: z.string().optional(),
  address: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  grossArea: z.number().positive().optional(),
  netArea: z.number().positive().optional(),
  roomCount: z.string().optional(),
  bathrooms: z.number().int().positive().optional(),
  buildingAge: z.number().int().min(0).optional(),
  floor: z.number().int().optional(),
  totalFloors: z.number().int().positive().optional(),
  heating: z.enum(['CENTRAL', 'INDIVIDUAL', 'FLOOR', 'AC', 'STOVE', 'NONE']).optional(),
  features: z.array(z.string()).default([]),
  ownerName: z.string().optional(),
  ownerPhone: z.string().optional(),
  commissionRate: z.number().min(0).max(100).optional(),
  commissionType: z.enum(['PERCENTAGE', 'FIXED']).optional(),
  tags: z.array(z.string()).default([]),
});

// ============================================================================
// CASE FILE
// ============================================================================

export const caseFileSchema = z.object({
  type: z.enum(['SALE', 'PURCHASE', 'RENTAL_TENANT', 'RENTAL_LANDLORD']),
  status: z.enum([
    'INITIAL_CONTACT', 'MEETING_SCHEDULED', 'SHOWING', 'NEGOTIATION',
    'OFFER_MADE', 'OFFER_ACCEPTED', 'CONTRACT_PREPARATION', 'CONTRACT_SIGNED',
    'DEPOSIT_RECEIVED', 'TITLE_DEED_TRANSFER', 'COMPLETED', 'CANCELLED'
  ]).default('INITIAL_CONTACT'),
  contactId: z.string().optional(),
  listingId: z.string().optional(),
  leadId: z.string().optional(),
  responsibleId: z.string().optional(),
  agreedPrice: z.number().positive().optional(),
  notes: z.string().optional(),
  tags: z.array(z.string()).default([]),
});

// ============================================================================
// ACTIVITY
// ============================================================================

export const activitySchema = z.object({
  type: z.enum(['CALL', 'EMAIL', 'MEETING', 'APPOINTMENT', 'SHOWING', 'FOLLOW_UP', 'TASK', 'NOTE']),
  title: z.string().min(1, 'Başlık zorunlu'),
  description: z.string().optional(),
  startAt: z.string().or(z.date()),
  endAt: z.string().or(z.date()).optional(),
  priority: z.enum(['LOW', 'MEDIUM', 'HIGH', 'URGENT']).default('MEDIUM'),
  assignedToId: z.string().optional(),
  caseFileId: z.string().optional(),
  leadId: z.string().optional(),
  reminderAt: z.string().or(z.date()).optional(),
});

// ============================================================================
// SHOWING
// ============================================================================

export const showingSchema = z.object({
  caseFileId: z.string().optional(),
  listingId: z.string(),
  scheduledAt: z.string().or(z.date()),
  duration: z.number().int().positive().default(30),
  assignedToId: z.string().optional(),
  status: z.enum(['SCHEDULED', 'CONFIRMED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'NO_SHOW']).default('SCHEDULED'),
});

export const showingCheckInSchema = z.object({
  latitude: z.number(),
  longitude: z.number(),
});

export const showingCheckOutSchema = z.object({
  clientFeedback: z.string().optional(),
  agentNotes: z.string().optional(),
  interestLevel: z.number().int().min(1).max(5).optional(),
});

// ============================================================================
// VIDEO JOB
// ============================================================================

export const videoJobSchema = z.object({
  images: z.array(z.object({
    url: z.string().url(),
    order: z.number().int().min(0),
  })).min(4, 'En az 4 görsel gerekli').max(4, 'En fazla 4 görsel yüklenebilir'),
  title: z.string().optional(),
  price: z.string().optional(),
  location: z.string().optional(),
  roomCount: z.string().optional(),
  listingId: z.string().optional(),
});

// ============================================================================
// DRONE ORDER
// ============================================================================

export const droneOrderSchema = z.object({
  package: z.enum(['BRONZE', 'SILVER', 'GOLD']),
  listingId: z.string().optional(),
  address: z.string().min(10, 'Adres en az 10 karakter olmalı'),
  city: z.string().min(1, 'İl zorunlu'),
  district: z.string().min(1, 'İlçe zorunlu'),
  scheduledDate: z.string().or(z.date()).optional(),
  scheduledTime: z.string().optional(),
  customerNotes: z.string().optional(),
});

// ============================================================================
// INTEGRATION
// ============================================================================

export const sahibindenConnectSchema = z.object({
  accessKey: z.string().min(10, 'Access key en az 10 karakter olmalı'),
});

// ============================================================================
// KVKK CONSENT
// ============================================================================

export const kvkkConsentSchema = z.object({
  contactId: z.string(),
  type: z.string(),
  version: z.string(),
  granted: z.boolean(),
  source: z.string().optional(),
});

// ============================================================================
// PAGINATION & FILTERS
// ============================================================================

export const paginationSchema = z.object({
  page: z.number().int().positive().default(1),
  limit: z.number().int().min(1).max(100).default(20),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

export const leadFilterSchema = paginationSchema.extend({
  status: z.string().optional(),
  source: z.string().optional(),
  assignedToId: z.string().optional(),
  temperature: z.string().optional(),
  search: z.string().optional(),
});

export const listingFilterSchema = paginationSchema.extend({
  status: z.string().optional(),
  type: z.string().optional(),
  transactionType: z.string().optional(),
  city: z.string().optional(),
  district: z.string().optional(),
  minPrice: z.number().optional(),
  maxPrice: z.number().optional(),
  roomCount: z.string().optional(),
  search: z.string().optional(),
});

// Type exports
export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
export type ContactInput = z.infer<typeof contactSchema>;
export type LeadInput = z.infer<typeof leadSchema>;
export type ListingInput = z.infer<typeof listingSchema>;
export type CaseFileInput = z.infer<typeof caseFileSchema>;
export type ActivityInput = z.infer<typeof activitySchema>;
export type ShowingInput = z.infer<typeof showingSchema>;
export type VideoJobInput = z.infer<typeof videoJobSchema>;
export type DroneOrderInput = z.infer<typeof droneOrderSchema>;
