// src/lib/notifications/sound.ts
// Client-side notification sound using Web Audio API - "çank çank"

export class NotificationSound {
  private audioContext: AudioContext | null = null;
  private isEnabled: boolean = true;

  constructor() {
    if (typeof window !== 'undefined') {
      this.initAudioContext();
    }
  }

  private initAudioContext() {
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (error) {
      console.warn('Web Audio API not supported:', error);
    }
  }

  setEnabled(enabled: boolean) {
    this.isEnabled = enabled;
  }

  async play() {
    if (!this.isEnabled || !this.audioContext) return;

    // Resume context if suspended (browser autoplay policy)
    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }

    try {
      // "çank çank" - Two pleasant notification tones
      this.playTone(880, 0, 0.12); // First "çank" - A5 note
      this.playTone(1046.5, 0.15, 0.12); // Second "çank" - C6 note
    } catch (error) {
      console.warn('Failed to play notification sound:', error);
    }
  }

  private playTone(frequency: number, delay: number, duration: number) {
    if (!this.audioContext) return;

    const startTime = this.audioContext.currentTime + delay;

    // Create oscillator
    const oscillator = this.audioContext.createOscillator();
    oscillator.type = 'sine';
    oscillator.frequency.value = frequency;

    // Create gain node for envelope
    const gainNode = this.audioContext.createGain();

    // Connect nodes
    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    // Envelope: quick attack, exponential decay
    gainNode.gain.setValueAtTime(0, startTime);
    gainNode.gain.linearRampToValueAtTime(0.3, startTime + 0.01); // Quick attack
    gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + duration); // Decay

    // Start and stop oscillator
    oscillator.start(startTime);
    oscillator.stop(startTime + duration);
  }
}

// Singleton instance
let notificationSound: NotificationSound | null = null;

export function getNotificationSound(): NotificationSound {
  if (!notificationSound) {
    notificationSound = new NotificationSound();
  }
  return notificationSound;
}

export function playNotificationSound() {
  getNotificationSound().play();
}

export function setNotificationSoundEnabled(enabled: boolean) {
  getNotificationSound().setEnabled(enabled);
}
