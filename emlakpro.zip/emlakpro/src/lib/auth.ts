// src/lib/auth.ts
import { NextAuthOptions, getServerSession } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { compare } from 'bcryptjs';
import prisma from './prisma';

export const authOptions: NextAuthOptions = {
  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  pages: {
    signIn: '/giris',
    error: '/giris',
  },
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          throw new Error('Email ve şifre zorunlu');
        }

        // Check if demo mode
        const isDemoMode = process.env.DEMO_ENABLED === 'true';
        const isDemoEmail = credentials.email.endsWith('@emlakpro.demo');

        if (isDemoMode && isDemoEmail) {
          // Demo login - find demo user
          const user = await prisma.user.findFirst({
            where: {
              email: credentials.email,
              tenant: { slug: process.env.DEMO_TENANT_SLUG || 'demo' },
            },
            include: { tenant: true },
          });

          if (!user) {
            throw new Error('Demo kullanıcı bulunamadı');
          }

          // Log demo login
          await prisma.auditLog.create({
            data: {
              tenantId: user.tenantId,
              userId: user.id,
              action: 'DEMO_LOGIN',
              entityType: 'User',
              entityId: user.id,
              description: `Demo giriş: ${user.email}`,
            },
          });

          return {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            tenantId: user.tenantId,
            tenantSlug: user.tenant.slug,
            isDemo: true,
          };
        }

        // Regular login
        const user = await prisma.user.findFirst({
          where: { email: credentials.email },
          include: { tenant: true },
        });

        if (!user) {
          throw new Error('Email veya şifre hatalı');
        }

        if (!user.isActive) {
          throw new Error('Hesabınız aktif değil');
        }

        const isValid = await compare(credentials.password, user.passwordHash);

        if (!isValid) {
          throw new Error('Email veya şifre hatalı');
        }

        // Update last login
        await prisma.user.update({
          where: { id: user.id },
          data: { lastLoginAt: new Date() },
        });

        // Log login
        await prisma.auditLog.create({
          data: {
            tenantId: user.tenantId,
            userId: user.id,
            action: 'LOGIN',
            entityType: 'User',
            entityId: user.id,
            description: `Kullanıcı giriş yaptı: ${user.email}`,
          },
        });

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          tenantId: user.tenantId,
          tenantSlug: user.tenant.slug,
          isDemo: false,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = user.role;
        token.tenantId = user.tenantId;
        token.tenantSlug = user.tenantSlug;
        token.isDemo = user.isDemo;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        session.user.role = token.role as string;
        session.user.tenantId = token.tenantId as string;
        session.user.tenantSlug = token.tenantSlug as string;
        session.user.isDemo = token.isDemo as boolean;
      }
      return session;
    },
  },
};

export async function getCurrentUser() {
  const session = await getServerSession(authOptions);
  return session?.user;
}

export async function getSession() {
  return await getServerSession(authOptions);
}
