// src/app/(dashboard)/dashboard/page.tsx
'use client';

import Link from 'next/link';
import {
  Phone, Building2, FolderKanban, TrendingUp, TrendingDown,
  Calendar, Clock, MapPin, ChevronRight, Flame, Thermometer, Snowflake,
  CheckCircle, AlertCircle, User
} from 'lucide-react';

// Mock Data
const stats = [
  { name: 'Yeni Leadler', value: '12', change: '+23%', trend: 'up', icon: Phone, color: 'blue' },
  { name: 'Aktif İlanlar', value: '48', change: '+5%', trend: 'up', icon: Building2, color: 'green' },
  { name: 'Açık Dosyalar', value: '23', change: '-2%', trend: 'down', icon: FolderKanban, color: 'purple' },
  { name: 'Bu Ay Satış', value: '₺2.4M', change: '+18%', trend: 'up', icon: TrendingUp, color: 'orange' },
];

const recentLeads = [
  { id: 1, name: 'Ahmet Kaya', phone: '0532 123 4567', source: 'Sahibinden', time: '5 dk önce', temp: 'hot', interest: 'Kadıköy 3+1' },
  { id: 2, name: 'Mehmet Demir', phone: '0533 234 5678', source: 'Website', time: '23 dk önce', temp: 'warm', interest: 'Beşiktaş kiralık' },
  { id: 3, name: 'Ayşe Yılmaz', phone: '0534 345 6789', source: 'Referans', time: '1 saat önce', temp: 'hot', interest: 'Villa satın alma' },
  { id: 4, name: 'Fatma Şahin', phone: '0535 456 7890', source: 'Telefon', time: '2 saat önce', temp: 'cold', interest: 'Yatırım amaçlı' },
];

const todayActivities = [
  { id: 1, time: '10:00', title: 'Müşteri görüşmesi - Fatma Hanım', type: 'meeting', status: 'upcoming' },
  { id: 2, time: '11:30', title: 'Moda dairesi gösterimi', type: 'showing', status: 'upcoming' },
  { id: 3, time: '14:00', title: 'Selin Hanım takip araması', type: 'call', status: 'upcoming' },
  { id: 4, time: '16:00', title: 'Sözleşme hazırlama - DF-2026-0003', type: 'task', status: 'urgent' },
];

const pipelineData = [
  { status: 'Yeni', count: 12, color: 'bg-blue-500' },
  { status: 'İletişimde', count: 8, color: 'bg-yellow-500' },
  { status: 'Nitelikli', count: 6, color: 'bg-purple-500' },
  { status: 'Görüşme', count: 4, color: 'bg-orange-500' },
  { status: 'Teklif', count: 3, color: 'bg-pink-500' },
  { status: 'Kazanıldı', count: 2, color: 'bg-green-500' },
];

export default function DashboardPage() {
  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Greeting */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Günaydın, Ahmet 👋</h1>
          <p className="text-slate-500">Bugün 4 randevun ve 12 yeni leadın var.</p>
        </div>
        <div className="hidden md:block text-right">
          <div className="text-sm text-slate-500">Bugün</div>
          <div className="text-lg font-semibold text-slate-900">13 Ocak 2026, Salı</div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          const colors: Record<string, string> = {
            blue: 'bg-blue-50 text-blue-600',
            green: 'bg-green-50 text-green-600',
            purple: 'bg-purple-50 text-purple-600',
            orange: 'bg-orange-50 text-orange-600',
          };
          return (
            <div key={stat.name} className="bg-white rounded-xl p-4 border border-slate-200 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div className={`p-2 rounded-lg ${colors[stat.color]}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className={`flex items-center gap-1 text-xs font-medium ${stat.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.trend === 'up' ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {stat.change}
                </div>
              </div>
              <div className="mt-3">
                <div className="text-2xl font-bold text-slate-900">{stat.value}</div>
                <div className="text-sm text-slate-500">{stat.name}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Leads */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200">
          <div className="flex items-center justify-between p-4 border-b border-slate-200">
            <h2 className="font-semibold text-slate-900">Son Leadler</h2>
            <Link href="/leadler" className="text-sm text-blue-600 hover:text-blue-700 flex items-center gap-1">
              Tümü <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="divide-y divide-slate-100">
            {recentLeads.map((lead) => (
              <div key={lead.id} className="p-4 hover:bg-slate-50 transition-colors cursor-pointer">
                <div className="flex items-start gap-3">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
                    <User className="h-5 w-5 text-slate-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-slate-900">{lead.name}</span>
                      {lead.temp === 'hot' && <Flame className="h-4 w-4 text-red-500" />}
                      {lead.temp === 'warm' && <Thermometer className="h-4 w-4 text-orange-500" />}
                      {lead.temp === 'cold' && <Snowflake className="h-4 w-4 text-blue-500" />}
                    </div>
                    <div className="text-sm text-slate-500">{lead.interest}</div>
                    <div className="flex items-center gap-3 mt-1 text-xs text-slate-400">
                      <span>{lead.phone}</span>
                      <span>•</span>
                      <span>{lead.source}</span>
                    </div>
                  </div>
                  <div className="text-xs text-slate-400">{lead.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Today's Activities */}
        <div className="bg-white rounded-xl border border-slate-200">
          <div className="flex items-center justify-between p-4 border-b border-slate-200">
            <h2 className="font-semibold text-slate-900">Bugün</h2>
            <Link href="/takvim" className="text-sm text-blue-600 hover:text-blue-700 flex items-center gap-1">
              Takvim <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="p-2">
            {todayActivities.map((activity) => (
              <div key={activity.id} className={`p-3 rounded-lg mb-2 ${activity.status === 'urgent' ? 'bg-red-50 border border-red-100' : 'hover:bg-slate-50'}`}>
                <div className="flex items-start gap-3">
                  <div className="text-sm font-medium text-slate-500 w-12">{activity.time}</div>
                  <div className="flex-1">
                    <div className={`text-sm font-medium ${activity.status === 'urgent' ? 'text-red-700' : 'text-slate-900'}`}>
                      {activity.title}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      {activity.type === 'meeting' && <Calendar className="h-3 w-3 text-blue-500" />}
                      {activity.type === 'showing' && <MapPin className="h-3 w-3 text-green-500" />}
                      {activity.type === 'call' && <Phone className="h-3 w-3 text-purple-500" />}
                      {activity.type === 'task' && <CheckCircle className="h-3 w-3 text-orange-500" />}
                      <span className="text-xs text-slate-400 capitalize">{activity.type}</span>
                      {activity.status === 'urgent' && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-600 font-medium">Acil</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pipeline Overview */}
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <h2 className="font-semibold text-slate-900 mb-4">Lead Pipeline</h2>
        <div className="flex items-end gap-2 h-32">
          {pipelineData.map((item, index) => (
            <div key={item.status} className="flex-1 flex flex-col items-center gap-2">
              <div className="text-sm font-bold text-slate-900">{item.count}</div>
              <div
                className={`w-full ${item.color} rounded-t-lg transition-all hover:opacity-80`}
                style={{ height: `${(item.count / 12) * 100}%`, minHeight: '20px' }}
              />
              <div className="text-xs text-slate-500 text-center">{item.status}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Yeni Lead', icon: Phone, href: '/leadler/yeni', color: 'from-blue-500 to-blue-600' },
          { label: 'Yeni İlan', icon: Building2, href: '/portfoy/yeni', color: 'from-green-500 to-green-600' },
          { label: 'Yeni Dosya', icon: FolderKanban, href: '/dosyalar/yeni', color: 'from-purple-500 to-purple-600' },
          { label: 'Randevu Ekle', icon: Calendar, href: '/takvim/yeni', color: 'from-orange-500 to-orange-600' },
        ].map((action) => {
          const Icon = action.icon;
          return (
            <Link
              key={action.label}
              href={action.href}
              className={`flex items-center gap-3 p-4 rounded-xl bg-gradient-to-r ${action.color} text-white hover:shadow-lg transition-shadow`}
            >
              <Icon className="h-5 w-5" />
              <span className="font-medium">{action.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
