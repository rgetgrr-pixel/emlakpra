// src/app/(dashboard)/leadler/page.tsx
'use client';

import { useState } from 'react';
import Link from 'next/link';
import {
  Phone, Plus, Filter, Search, MoreVertical, Flame, Thermometer, Snowflake,
  Clock, User, Building2, ChevronDown, LayoutGrid, List, ArrowUpDown
} from 'lucide-react';

const columns = [
  { id: 'NEW', title: 'Yeni', color: 'bg-blue-500' },
  { id: 'CONTACTED', title: 'İletişimde', color: 'bg-yellow-500' },
  { id: 'QUALIFIED', title: 'Nitelikli', color: 'bg-purple-500' },
  { id: 'MEETING', title: 'Görüşme', color: 'bg-orange-500' },
  { id: 'NEGOTIATION', title: 'Pazarlık', color: 'bg-pink-500' },
  { id: 'WON', title: 'Kazanıldı', color: 'bg-green-500' },
];

const mockLeads = [
  { id: 1, name: 'Ahmet Kaya', phone: '0532 123 4567', source: 'Sahibinden', status: 'NEW', temp: 'hot', interest: 'Kadıköy 3+1 daire', budget: '2.5M - 3M TL', time: '5 dk önce', agent: null },
  { id: 2, name: 'Mehmet Demir', phone: '0533 234 5678', source: 'Website', status: 'NEW', temp: 'warm', interest: 'Beşiktaş kiralık ofis', budget: '30K - 50K TL/ay', time: '23 dk önce', agent: null },
  { id: 3, name: 'Zeynep Aksoy', phone: '0534 111 2222', source: 'Referans', status: 'NEW', temp: 'hot', interest: 'Ataşehir residence', budget: '4M - 5M TL', time: '1 saat önce', agent: null },
  { id: 4, name: 'Ayşe Yılmaz', phone: '0534 345 6789', source: 'Referans', status: 'CONTACTED', temp: 'hot', interest: 'Villa satın alma', budget: '10M+ TL', time: '2 gün önce', agent: 'Mehmet' },
  { id: 5, name: 'Ali Öztürk', phone: '0535 222 3333', source: 'Telefon', status: 'CONTACTED', temp: 'warm', interest: 'Yatırım amaçlı daire', budget: '1.5M - 2M TL', time: '3 gün önce', agent: 'Zeynep' },
  { id: 6, name: 'Fatma Şahin', phone: '0535 456 7890', source: 'Telefon', status: 'QUALIFIED', temp: 'hot', interest: 'Şişli merkezi konum', budget: '3M - 4M TL', time: '1 hafta önce', agent: 'Mehmet' },
  { id: 7, name: 'Hasan Çelik', phone: '0536 333 4444', source: 'Sahibinden', status: 'QUALIFIED', temp: 'warm', interest: 'Bahçeli müstakil ev', budget: '5M - 7M TL', time: '5 gün önce', agent: 'Zeynep' },
  { id: 8, name: 'Elif Arslan', phone: '0537 444 5555', source: 'Instagram', status: 'MEETING', temp: 'hot', interest: 'Deniz manzaralı daire', budget: '6M - 8M TL', time: '2 hafta önce', agent: 'Mehmet' },
  { id: 9, name: 'Murat Koç', phone: '0538 555 6666', source: 'Website', status: 'NEGOTIATION', temp: 'hot', interest: 'Levent ofis', budget: '50K - 70K TL/ay', time: '3 hafta önce', agent: 'Zeynep' },
  { id: 10, name: 'Selin Yıldız', phone: '0539 666 7777', source: 'Referans', status: 'WON', temp: 'hot', interest: 'Kadıköy 2+1 daire', budget: '2.2M TL', time: '1 ay önce', agent: 'Mehmet' },
];

export default function LeadlerPage() {
  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');
  const [searchQuery, setSearchQuery] = useState('');

  const getLeadsByStatus = (status: string) => mockLeads.filter(l => l.status === status);

  const TempIcon = ({ temp }: { temp: string }) => {
    if (temp === 'hot') return <Flame className="h-4 w-4 text-red-500" />;
    if (temp === 'warm') return <Thermometer className="h-4 w-4 text-orange-500" />;
    return <Snowflake className="h-4 w-4 text-blue-500" />;
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 lg:p-6 border-b border-slate-200 bg-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Leadler</h1>
            <p className="text-slate-500">Toplam {mockLeads.length} lead</p>
          </div>
          <div className="flex items-center gap-2">
            <Link
              href="/leadler/yeni"
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4" />
              <span>Yeni Lead</span>
            </Link>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 mt-4">
          <div className="relative flex-1 min-w-[200px] max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Lead ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button className="flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg hover:bg-slate-50">
            <Filter className="h-4 w-4" />
            <span>Filtrele</span>
            <ChevronDown className="h-4 w-4" />
          </button>
          <button className="flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg hover:bg-slate-50">
            <ArrowUpDown className="h-4 w-4" />
            <span>Sırala</span>
          </button>
          <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('kanban')}
              className={`p-2 ${viewMode === 'kanban' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 ${viewMode === 'list' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Kanban Board */}
      {viewMode === 'kanban' && (
        <div className="flex-1 overflow-x-auto p-4 lg:p-6">
          <div className="flex gap-4 h-full min-w-max">
            {columns.map((column) => {
              const leads = getLeadsByStatus(column.id);
              return (
                <div key={column.id} className="w-80 flex-shrink-0 flex flex-col bg-slate-100 rounded-xl">
                  {/* Column Header */}
                  <div className="p-3 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${column.color}`} />
                      <span className="font-medium text-slate-700">{column.title}</span>
                      <span className="text-sm text-slate-500 bg-white px-2 py-0.5 rounded-full">{leads.length}</span>
                    </div>
                    <button className="p-1 hover:bg-slate-200 rounded">
                      <Plus className="h-4 w-4 text-slate-500" />
                    </button>
                  </div>

                  {/* Cards */}
                  <div className="flex-1 overflow-y-auto p-2 space-y-2">
                    {leads.map((lead) => (
                      <div
                        key={lead.id}
                        className="bg-white rounded-lg p-3 shadow-sm border border-slate-200 hover:shadow-md transition-shadow cursor-pointer"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
                              <User className="h-4 w-4 text-slate-500" />
                            </div>
                            <div>
                              <div className="font-medium text-slate-900 text-sm">{lead.name}</div>
                              <div className="text-xs text-slate-500">{lead.phone}</div>
                            </div>
                          </div>
                          <TempIcon temp={lead.temp} />
                        </div>
                        <div className="text-sm text-slate-600 mb-2">{lead.interest}</div>
                        <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
                          <Building2 className="h-3 w-3" />
                          <span>{lead.budget}</span>
                        </div>
                        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                          <div className="flex items-center gap-1 text-xs text-slate-400">
                            <Clock className="h-3 w-3" />
                            <span>{lead.time}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">{lead.source}</span>
                            {lead.agent && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-blue-50 text-blue-600">{lead.agent}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* List View */}
      {viewMode === 'list' && (
        <div className="flex-1 overflow-auto p-4 lg:p-6">
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left p-4 text-sm font-medium text-slate-600">Lead</th>
                  <th className="text-left p-4 text-sm font-medium text-slate-600">İlgi Alanı</th>
                  <th className="text-left p-4 text-sm font-medium text-slate-600">Bütçe</th>
                  <th className="text-left p-4 text-sm font-medium text-slate-600">Kaynak</th>
                  <th className="text-left p-4 text-sm font-medium text-slate-600">Durum</th>
                  <th className="text-left p-4 text-sm font-medium text-slate-600">Sorumlu</th>
                  <th className="text-left p-4 text-sm font-medium text-slate-600"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {mockLeads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-slate-50 cursor-pointer">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <TempIcon temp={lead.temp} />
                        <div>
                          <div className="font-medium text-slate-900">{lead.name}</div>
                          <div className="text-sm text-slate-500">{lead.phone}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 text-sm text-slate-600">{lead.interest}</td>
                    <td className="p-4 text-sm text-slate-600">{lead.budget}</td>
                    <td className="p-4">
                      <span className="text-xs px-2 py-1 rounded-full bg-slate-100 text-slate-600">{lead.source}</span>
                    </td>
                    <td className="p-4">
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        lead.status === 'NEW' ? 'bg-blue-100 text-blue-700' :
                        lead.status === 'CONTACTED' ? 'bg-yellow-100 text-yellow-700' :
                        lead.status === 'QUALIFIED' ? 'bg-purple-100 text-purple-700' :
                        lead.status === 'MEETING' ? 'bg-orange-100 text-orange-700' :
                        lead.status === 'NEGOTIATION' ? 'bg-pink-100 text-pink-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {columns.find(c => c.id === lead.status)?.title}
                      </span>
                    </td>
                    <td className="p-4 text-sm text-slate-600">{lead.agent || '-'}</td>
                    <td className="p-4">
                      <button className="p-1 hover:bg-slate-100 rounded">
                        <MoreVertical className="h-4 w-4 text-slate-400" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
