// src/app/(dashboard)/dosyalar/page.tsx
'use client';

import { useState } from 'react';
import Link from 'next/link';
import {
  Plus, Search, Filter, ChevronRight, Clock, User, Building2, Phone,
  CheckCircle, Circle, AlertCircle, FileText, Calendar, MoreVertical
} from 'lucide-react';

const statusSteps = [
  { id: 'INITIAL_CONTACT', label: 'İlk Temas', icon: Phone },
  { id: 'SHOWING', label: 'Gösterim', icon: Building2 },
  { id: 'NEGOTIATION', label: 'Pazarlık', icon: FileText },
  { id: 'CONTRACT', label: 'Sözleşme', icon: FileText },
  { id: 'COMPLETED', label: 'Tamamlandı', icon: CheckCircle },
];

const mockCaseFiles = [
  {
    id: 1,
    refNumber: 'DF-2026-0001',
    type: 'SALE',
    status: 'SHOWING',
    statusIndex: 1,
    contact: { name: 'Ahmet Kaya', phone: '0532 123 4567' },
    listing: { title: 'Kadıköy Moda 3+1 Daire', price: 2500000 },
    responsible: 'Mehmet Danışman',
    lastActivity: 'Gösterim planlandı',
    lastActivityTime: '2 saat önce',
    nextAction: 'İkinci gösterim',
    nextActionDate: '15 Ocak 14:00',
    priority: 'high',
    created: '5 gün önce',
  },
  {
    id: 2,
    refNumber: 'DF-2026-0002',
    type: 'PURCHASE',
    status: 'NEGOTIATION',
    statusIndex: 2,
    contact: { name: 'Selin Yıldız', phone: '0533 234 5678' },
    listing: { title: 'Sarıyer Tarabya Villa', price: 12000000 },
    responsible: 'Zeynep Danışman',
    lastActivity: 'Fiyat görüşmesi yapıldı',
    lastActivityTime: '1 gün önce',
    nextAction: 'Teklif sunumu',
    nextActionDate: '16 Ocak 10:00',
    agreedPrice: 11500000,
    priority: 'high',
    created: '2 hafta önce',
  },
  {
    id: 3,
    refNumber: 'DF-2026-0003',
    type: 'RENTAL_TENANT',
    status: 'CONTRACT',
    statusIndex: 3,
    contact: { name: 'Elif Arslan', phone: '0534 345 6789' },
    listing: { title: 'Beşiktaş Levent Ofis', price: 45000 },
    responsible: 'Mehmet Danışman',
    lastActivity: 'Sözleşme hazırlanıyor',
    lastActivityTime: '3 saat önce',
    nextAction: 'Sözleşme imzası',
    nextActionDate: '14 Ocak 16:00',
    agreedPrice: 42000,
    priority: 'urgent',
    created: '3 hafta önce',
  },
  {
    id: 4,
    refNumber: 'DF-2026-0004',
    type: 'SALE',
    status: 'COMPLETED',
    statusIndex: 4,
    contact: { name: 'Murat Koç', phone: '0535 456 7890' },
    listing: { title: 'Ataşehir Residence 2+1', price: 1800000 },
    responsible: 'Zeynep Danışman',
    lastActivity: 'Satış tamamlandı',
    lastActivityTime: '5 gün önce',
    agreedPrice: 1750000,
    commission: 52500,
    priority: 'normal',
    created: '1 ay önce',
  },
  {
    id: 5,
    refNumber: 'DF-2026-0005',
    type: 'PURCHASE',
    status: 'INITIAL_CONTACT',
    statusIndex: 0,
    contact: { name: 'ABC Holding', phone: '0212 123 4567', isCompany: true },
    listing: null,
    responsible: 'Mehmet Danışman',
    lastActivity: 'İlk görüşme yapıldı',
    lastActivityTime: '1 gün önce',
    nextAction: 'Portföy sunumu',
    nextActionDate: '17 Ocak 14:00',
    priority: 'normal',
    created: '2 gün önce',
  },
];

const typeLabels: Record<string, string> = {
  SALE: 'Satış',
  PURCHASE: 'Alım',
  RENTAL_TENANT: 'Kiralama (Kiracı)',
  RENTAL_LANDLORD: 'Kiralama (Ev Sahibi)',
};

const formatPrice = (price: number) => new Intl.NumberFormat('tr-TR').format(price);

export default function DosyalarPage() {
  const [filter, setFilter] = useState('all');

  const filteredFiles = filter === 'all' 
    ? mockCaseFiles 
    : mockCaseFiles.filter(f => f.status === filter);

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dosyalar</h1>
          <p className="text-slate-500">{mockCaseFiles.length} aktif dosya</p>
        </div>
        <Link
          href="/dosyalar/yeni"
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-4 w-4" />
          <span>Yeni Dosya</span>
        </Link>
      </div>

      {/* Status Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
            filter === 'all' ? 'bg-blue-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Tümü ({mockCaseFiles.length})
        </button>
        {statusSteps.slice(0, -1).map((step) => {
          const count = mockCaseFiles.filter(f => f.status === step.id).length;
          return (
            <button
              key={step.id}
              onClick={() => setFilter(step.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                filter === step.id ? 'bg-blue-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {step.label} ({count})
            </button>
          );
        })}
        <button
          onClick={() => setFilter('COMPLETED')}
          className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
            filter === 'COMPLETED' ? 'bg-green-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Tamamlanan ({mockCaseFiles.filter(f => f.status === 'COMPLETED').length})
        </button>
      </div>

      {/* Case File Cards */}
      <div className="space-y-4">
        {filteredFiles.map((file) => (
          <div 
            key={file.id} 
            className={`bg-white rounded-xl border overflow-hidden hover:shadow-md transition-shadow ${
              file.priority === 'urgent' ? 'border-red-200' : 
              file.priority === 'high' ? 'border-orange-200' : 'border-slate-200'
            }`}
          >
            {/* Progress Bar */}
            <div className="h-1 bg-slate-100">
              <div 
                className={`h-full transition-all ${file.status === 'COMPLETED' ? 'bg-green-500' : 'bg-blue-500'}`}
                style={{ width: `${((file.statusIndex + 1) / statusSteps.length) * 100}%` }}
              />
            </div>

            <div className="p-4">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${
                    file.status === 'COMPLETED' ? 'bg-green-100' :
                    file.priority === 'urgent' ? 'bg-red-100' :
                    file.priority === 'high' ? 'bg-orange-100' : 'bg-blue-100'
                  }`}>
                    {file.status === 'COMPLETED' ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : file.priority === 'urgent' ? (
                      <AlertCircle className="h-5 w-5 text-red-600" />
                    ) : (
                      <FileText className={`h-5 w-5 ${file.priority === 'high' ? 'text-orange-600' : 'text-blue-600'}`} />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{file.refNumber}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                        {typeLabels[file.type]}
                      </span>
                      {file.priority === 'urgent' && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-600 font-medium">
                          Acil
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-slate-500">{file.contact.name}</div>
                  </div>
                </div>
                <button className="p-1 hover:bg-slate-100 rounded">
                  <MoreVertical className="h-4 w-4 text-slate-400" />
                </button>
              </div>

              {/* Status Steps */}
              <div className="flex items-center gap-1 mb-4 overflow-x-auto pb-2">
                {statusSteps.map((step, index) => {
                  const Icon = step.icon;
                  const isCompleted = index <= file.statusIndex;
                  const isCurrent = index === file.statusIndex;
                  
                  return (
                    <div key={step.id} className="flex items-center">
                      <div className={`flex items-center gap-1.5 px-2 py-1 rounded-full text-xs whitespace-nowrap ${
                        isCompleted 
                          ? isCurrent 
                            ? 'bg-blue-100 text-blue-700 font-medium' 
                            : 'bg-green-100 text-green-700'
                          : 'bg-slate-100 text-slate-400'
                      }`}>
                        <Icon className="h-3 w-3" />
                        <span className="hidden sm:inline">{step.label}</span>
                      </div>
                      {index < statusSteps.length - 1 && (
                        <ChevronRight className={`h-4 w-4 mx-0.5 ${isCompleted ? 'text-green-400' : 'text-slate-300'}`} />
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Details */}
              <div className="grid sm:grid-cols-2 gap-4">
                {/* Left - Listing */}
                {file.listing && (
                  <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                    <Building2 className="h-5 w-5 text-slate-400 mt-0.5" />
                    <div>
                      <div className="text-sm font-medium text-slate-900">{file.listing.title}</div>
                      <div className="text-sm text-blue-600 font-semibold">₺{formatPrice(file.listing.price)}</div>
                      {file.agreedPrice && (
                        <div className="text-xs text-green-600">
                          Anlaşılan: ₺{formatPrice(file.agreedPrice)}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Right - Activity */}
                <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                  <Clock className="h-5 w-5 text-slate-400 mt-0.5" />
                  <div>
                    <div className="text-sm text-slate-600">{file.lastActivity}</div>
                    <div className="text-xs text-slate-400">{file.lastActivityTime}</div>
                    {file.nextAction && (
                      <div className="mt-2 flex items-center gap-1 text-xs text-orange-600">
                        <Calendar className="h-3 w-3" />
                        <span>{file.nextAction} - {file.nextActionDate}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-100">
                <div className="flex items-center gap-4 text-sm text-slate-500">
                  <div className="flex items-center gap-1">
                    <User className="h-4 w-4" />
                    <span>{file.responsible}</span>
                  </div>
                  <span>•</span>
                  <span>Oluşturulma: {file.created}</span>
                </div>
                {file.commission && (
                  <div className="text-sm font-semibold text-green-600">
                    Komisyon: ₺{formatPrice(file.commission)}
                  </div>
                )}
                <Link 
                  href={`/dosyalar/${file.id}`}
                  className="text-sm text-blue-600 hover:text-blue-700 flex items-center gap-1"
                >
                  Detaylar <ChevronRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
