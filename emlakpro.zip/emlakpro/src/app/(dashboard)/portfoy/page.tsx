// src/app/(dashboard)/portfoy/page.tsx
'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {
  Plus, Search, Filter, LayoutGrid, List, MapPin, Bed, Bath, Maximize,
  Heart, Share2, Eye, MoreVertical, ChevronDown, Building2
} from 'lucide-react';

const mockListings = [
  {
    id: 1,
    title: 'Kadıköy Moda\'da Deniz Manzaralı 3+1 Daire',
    type: 'Daire',
    transaction: 'Satılık',
    price: 2500000,
    city: 'İstanbul',
    district: 'Kadıköy',
    neighborhood: 'Moda',
    area: 145,
    rooms: '3+1',
    bathrooms: 2,
    floor: '7/10',
    age: 5,
    image: 'https://picsum.photos/seed/apt1/400/300',
    status: 'active',
    views: 234,
    favorites: 12,
    agent: 'Mehmet Danışman',
  },
  {
    id: 2,
    title: 'Beşiktaş Levent\'te A+ Ofis',
    type: 'Ofis',
    transaction: 'Kiralık',
    price: 45000,
    city: 'İstanbul',
    district: 'Beşiktaş',
    neighborhood: 'Levent',
    area: 200,
    rooms: '-',
    bathrooms: 2,
    floor: '15/30',
    age: 2,
    image: 'https://picsum.photos/seed/office1/400/300',
    status: 'active',
    views: 156,
    favorites: 8,
    agent: 'Zeynep Danışman',
  },
  {
    id: 3,
    title: 'Sarıyer\'de Boğaz Manzaralı Villa',
    type: 'Villa',
    transaction: 'Satılık',
    price: 12000000,
    city: 'İstanbul',
    district: 'Sarıyer',
    neighborhood: 'Tarabya',
    area: 450,
    rooms: '6+2',
    bathrooms: 4,
    floor: '3 Katlı',
    age: 8,
    image: 'https://picsum.photos/seed/villa1/400/300',
    status: 'active',
    views: 412,
    favorites: 28,
    agent: 'Mehmet Danışman',
  },
  {
    id: 4,
    title: 'Ataşehir\'de Yatırımlık 2+1 Residence',
    type: 'Residence',
    transaction: 'Satılık',
    price: 1800000,
    city: 'İstanbul',
    district: 'Ataşehir',
    neighborhood: 'Finanskent',
    area: 95,
    rooms: '2+1',
    bathrooms: 1,
    floor: '12/25',
    age: 1,
    image: 'https://picsum.photos/seed/res1/400/300',
    status: 'active',
    views: 189,
    favorites: 15,
    agent: 'Zeynep Danışman',
  },
  {
    id: 5,
    title: 'Üsküdar\'da Tarihi Yalı',
    type: 'Villa',
    transaction: 'Satılık',
    price: 35000000,
    city: 'İstanbul',
    district: 'Üsküdar',
    neighborhood: 'Kuzguncuk',
    area: 600,
    rooms: '8+3',
    bathrooms: 6,
    floor: '3 Katlı',
    age: 120,
    image: 'https://picsum.photos/seed/yali1/400/300',
    status: 'active',
    views: 567,
    favorites: 42,
    agent: 'Mehmet Danışman',
  },
  {
    id: 6,
    title: 'Şişli Mecidiyeköy\'de İşyeri',
    type: 'Dükkan',
    transaction: 'Kiralık',
    price: 25000,
    city: 'İstanbul',
    district: 'Şişli',
    neighborhood: 'Mecidiyeköy',
    area: 80,
    rooms: '-',
    bathrooms: 1,
    floor: 'Giriş',
    age: 15,
    image: 'https://picsum.photos/seed/shop1/400/300',
    status: 'draft',
    views: 0,
    favorites: 0,
    agent: 'Zeynep Danışman',
  },
];

const formatPrice = (price: number, transaction: string) => {
  const formatted = new Intl.NumberFormat('tr-TR').format(price);
  return transaction === 'Kiralık' ? `₺${formatted}/ay` : `₺${formatted}`;
};

export default function PortfoyPage() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Portföy</h1>
          <p className="text-slate-500">Toplam {mockListings.length} ilan</p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            href="/portfoy/yeni"
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Yeni İlan</span>
          </Link>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="İlan ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <select className="px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white">
          <option value="">Tüm Tipler</option>
          <option value="apartment">Daire</option>
          <option value="villa">Villa</option>
          <option value="office">Ofis</option>
          <option value="shop">Dükkan</option>
        </select>
        <select className="px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white">
          <option value="">Tüm İşlemler</option>
          <option value="sale">Satılık</option>
          <option value="rent">Kiralık</option>
        </select>
        <select className="px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white">
          <option value="">Tüm İlçeler</option>
          <option value="kadikoy">Kadıköy</option>
          <option value="besiktas">Beşiktaş</option>
          <option value="sariyer">Sarıyer</option>
          <option value="sisli">Şişli</option>
        </select>
        <button className="flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg hover:bg-slate-50">
          <Filter className="h-4 w-4" />
          <span>Daha Fazla</span>
        </button>
        <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden ml-auto">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 ${viewMode === 'grid' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <LayoutGrid className="h-4 w-4" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 ${viewMode === 'list' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <List className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Listings Grid */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockListings.map((listing) => (
            <div key={listing.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-shadow group">
              {/* Image */}
              <div className="relative aspect-[4/3] bg-slate-200">
                <img
                  src={listing.image}
                  alt={listing.title}
                  className="w-full h-full object-cover"
                />
                {/* Badges */}
                <div className="absolute top-3 left-3 flex gap-2">
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                    listing.transaction === 'Satılık' ? 'bg-green-500 text-white' : 'bg-blue-500 text-white'
                  }`}>
                    {listing.transaction}
                  </span>
                  {listing.status === 'draft' && (
                    <span className="text-xs px-2 py-1 rounded-full bg-slate-500 text-white font-medium">Taslak</span>
                  )}
                </div>
                {/* Actions */}
                <div className="absolute top-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-2 bg-white/90 rounded-full hover:bg-white shadow">
                    <Heart className="h-4 w-4 text-slate-600" />
                  </button>
                  <button className="p-2 bg-white/90 rounded-full hover:bg-white shadow">
                    <Share2 className="h-4 w-4 text-slate-600" />
                  </button>
                </div>
                {/* Type badge */}
                <div className="absolute bottom-3 left-3">
                  <span className="text-xs px-2 py-1 rounded bg-black/50 text-white">{listing.type}</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h3 className="font-semibold text-slate-900 line-clamp-2">{listing.title}</h3>
                  <button className="p-1 hover:bg-slate-100 rounded shrink-0">
                    <MoreVertical className="h-4 w-4 text-slate-400" />
                  </button>
                </div>

                <div className="flex items-center gap-1 text-sm text-slate-500 mb-3">
                  <MapPin className="h-4 w-4" />
                  <span>{listing.district}, {listing.neighborhood}</span>
                </div>

                <div className="flex items-center gap-4 text-sm text-slate-600 mb-3">
                  {listing.rooms !== '-' && (
                    <div className="flex items-center gap-1">
                      <Bed className="h-4 w-4" />
                      <span>{listing.rooms}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <Bath className="h-4 w-4" />
                    <span>{listing.bathrooms}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Maximize className="h-4 w-4" />
                    <span>{listing.area} m²</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                  <div className="text-xl font-bold text-blue-600">
                    {formatPrice(listing.price, listing.transaction)}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-400">
                    <div className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      <span>{listing.views}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="h-3 w-3" />
                      <span>{listing.favorites}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Listings List */}
      {viewMode === 'list' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-slate-600">İlan</th>
                <th className="text-left p-4 text-sm font-medium text-slate-600">Konum</th>
                <th className="text-left p-4 text-sm font-medium text-slate-600">Özellikler</th>
                <th className="text-left p-4 text-sm font-medium text-slate-600">Fiyat</th>
                <th className="text-left p-4 text-sm font-medium text-slate-600">Durum</th>
                <th className="text-left p-4 text-sm font-medium text-slate-600">Görüntülenme</th>
                <th className="text-left p-4 text-sm font-medium text-slate-600"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mockListings.map((listing) => (
                <tr key={listing.id} className="hover:bg-slate-50 cursor-pointer">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <img src={listing.image} alt="" className="w-16 h-12 rounded object-cover" />
                      <div>
                        <div className="font-medium text-slate-900 line-clamp-1">{listing.title}</div>
                        <div className="text-sm text-slate-500">{listing.type} • {listing.transaction}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 text-sm text-slate-600">{listing.district}, {listing.neighborhood}</td>
                  <td className="p-4 text-sm text-slate-600">{listing.rooms} • {listing.area}m²</td>
                  <td className="p-4 font-semibold text-blue-600">{formatPrice(listing.price, listing.transaction)}</td>
                  <td className="p-4">
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      listing.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {listing.status === 'active' ? 'Aktif' : 'Taslak'}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-slate-600">{listing.views}</td>
                  <td className="p-4">
                    <button className="p-1 hover:bg-slate-100 rounded">
                      <MoreVertical className="h-4 w-4 text-slate-400" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
