// src/app/demo/page.tsx
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  Building2, 
  Users, 
  Shield, 
  Phone, 
  MapPin, 
  User,
  ArrowRight,
  Sparkles,
  CheckCircle
} from 'lucide-react';

const demoUsers = [
  {
    role: 'ADMIN',
    name: 'Ahmet Yönetici',
    email: 'demo_admin@emlakpro.demo',
    description: 'Tüm modüllere tam erişim, kullanıcı yönetimi, raporlar',
    icon: Shield,
    color: 'from-purple-500 to-purple-600',
    features: ['Tüm modüller', 'Kullanıcı yönetimi', 'Raporlar', 'Ayarlar'],
  },
  {
    role: 'SECRETARY',
    name: 'Ayşe Sekreter',
    email: 'demo_secretary@emlakpro.demo',
    description: 'Lead atama, takvim yönetimi, dosya takibi',
    icon: Users,
    color: 'from-blue-500 to-blue-600',
    features: ['Lead yönetimi', 'Takvim', 'Dosya takibi', 'Entegrasyonlar'],
  },
  {
    role: 'AGENT',
    name: 'Mehmet Danışman',
    email: 'demo_agent@emlakpro.demo',
    description: 'Kendi leadleri, portföy, AI stüdyo, gösterimler',
    icon: Phone,
    color: 'from-green-500 to-green-600',
    features: ['Kendi leadleri', 'Portföy', 'AI Stüdyo', 'Gösterimler'],
  },
  {
    role: 'FIELD',
    name: 'Ali Saha',
    email: 'demo_field@emlakpro.demo',
    description: 'Gösterim check-in, fotoğraf yükleme, konum takibi',
    icon: MapPin,
    color: 'from-orange-500 to-orange-600',
    features: ['Gösterimler', 'Check-in', 'Fotoğraf', 'Harita'],
  },
  {
    role: 'CLIENT',
    name: 'Fatma Müşteri',
    email: 'demo_client@emlakpro.demo',
    description: 'Dosya durumu, belgeler, bildirimler',
    icon: User,
    color: 'from-pink-500 to-pink-600',
    features: ['Dosya takibi', 'Belgeler', 'Bildirimler'],
  },
];

export default function DemoPage() {
  const [selectedRole, setSelectedRole] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
              <Building2 className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold text-white">EmlakPro</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-400">Demo Modu</span>
            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
          </div>
        </div>
      </header>

      {/* Hero */}
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 mb-6">
          <Sparkles className="h-4 w-4 text-blue-400" />
          <span className="text-sm text-blue-400">Demo Ortamı</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
          EmlakPro CRM Demo
        </h1>
        <p className="text-lg text-slate-400 max-w-2xl mx-auto mb-8">
          Farklı roller ile sistemi deneyimleyin. Her rol farklı yetkilere ve ekranlara sahiptir.
        </p>
      </div>

      {/* Role Cards */}
      <div className="container mx-auto px-4 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {demoUsers.map((user) => {
            const Icon = user.icon;
            const isSelected = selectedRole === user.role;
            
            return (
              <div
                key={user.role}
                onClick={() => setSelectedRole(user.role)}
                className={`
                  relative group cursor-pointer rounded-2xl border transition-all duration-300
                  ${isSelected 
                    ? 'border-blue-500 bg-slate-800/80 scale-[1.02] shadow-xl shadow-blue-500/20' 
                    : 'border-white/10 bg-slate-800/50 hover:border-white/20 hover:bg-slate-800/70'
                  }
                `}
              >
                <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${user.color} opacity-0 group-hover:opacity-5 transition-opacity`} />
                
                <div className="relative p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`h-12 w-12 rounded-xl bg-gradient-to-br ${user.color} flex items-center justify-center shadow-lg`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    {isSelected && (
                      <CheckCircle className="h-6 w-6 text-blue-500" />
                    )}
                  </div>

                  <h3 className="text-lg font-semibold text-white mb-1">
                    {user.name}
                  </h3>
                  <p className="text-sm text-slate-400 mb-4">
                    {user.description}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {user.features.map((feature) => (
                      <span
                        key={feature}
                        className="text-xs px-2 py-1 rounded-full bg-white/5 text-slate-300"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>

                  <div className="text-xs text-slate-500 font-mono">
                    {user.email}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {selectedRole && (
          <div className="mt-8 text-center">
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all hover:scale-105"
            >
              {demoUsers.find(u => u.role === selectedRole)?.name} olarak giriş yap
              <ArrowRight className="h-5 w-5" />
            </Link>
          </div>
        )}
      </div>

      {/* Features Preview */}
      <div className="border-t border-white/10 bg-slate-900/50">
        <div className="container mx-auto px-4 py-16">
          <h2 className="text-2xl font-bold text-white text-center mb-12">
            Platform Özellikleri
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            {[
              { icon: '📊', label: 'Lead Pipeline', desc: 'Kanban görünümü' },
              { icon: '🏠', label: 'Portföy', desc: '500+ ilan' },
              { icon: '📁', label: 'Dosya Sistemi', desc: 'Timeline takip' },
              { icon: '🤖', label: 'AI Stüdyo', desc: 'Video & içerik' },
              { icon: '🚁', label: 'Drone Çekim', desc: 'Sipariş sistemi' },
              { icon: '📍', label: 'Gösterimler', desc: 'Check-in/out' },
              { icon: '📄', label: 'Sözleşmeler', desc: 'Dijital imza' },
              { icon: '📈', label: 'Raporlar', desc: 'Analitik' },
            ].map((item) => (
              <div key={item.label} className="text-center">
                <div className="text-3xl mb-2">{item.icon}</div>
                <div className="text-sm font-medium text-white">{item.label}</div>
                <div className="text-xs text-slate-500">{item.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <footer className="border-t border-white/10 py-6">
        <div className="container mx-auto px-4 text-center text-sm text-slate-500">
          Demo ortamı • Veriler her 24 saatte sıfırlanır • © 2024 EmlakPro
        </div>
      </footer>
    </div>
  );
}
