// src/app/api/leads/route.ts
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { withPermission, buildOwnershipWhereClause } from '@/middleware/rbac';
import { createAuditLog } from '@/middleware/audit';
import { leadSchema, leadFilterSchema } from '@/lib/validations';
import { UserRole } from '@prisma/client';

export const GET = withPermission('leads:list')(
  async (request: NextRequest, { session }) => {
    try {
      const { searchParams } = new URL(request.url);
      
      const filters = leadFilterSchema.parse({
        page: parseInt(searchParams.get('page') || '1'),
        limit: parseInt(searchParams.get('limit') || '20'),
        sortBy: searchParams.get('sortBy') || 'createdAt',
        sortOrder: searchParams.get('sortOrder') || 'desc',
        status: searchParams.get('status') || undefined,
        source: searchParams.get('source') || undefined,
        assignedToId: searchParams.get('assignedToId') || undefined,
        temperature: searchParams.get('temperature') || undefined,
        search: searchParams.get('search') || undefined,
      });

      const { page, limit, sortBy, sortOrder, status, source, assignedToId, temperature, search } = filters;

      // Build where clause based on role
      const baseWhere = buildOwnershipWhereClause(
        session.user.tenantId,
        session.user.id,
        session.user.role as UserRole,
        'assignedToId'
      );

      const where = {
        ...baseWhere,
        ...(status && { status }),
        ...(source && { source }),
        ...(assignedToId && { assignedToId }),
        ...(temperature && { temperature }),
        ...(search && {
          OR: [
            { name: { contains: search, mode: 'insensitive' as const } },
            { phone: { contains: search } },
            { email: { contains: search, mode: 'insensitive' as const } },
          ],
        }),
      };

      const [leads, total] = await Promise.all([
        prisma.lead.findMany({
          where,
          orderBy: { [sortBy]: sortOrder },
          skip: (page - 1) * limit,
          take: limit,
          include: {
            assignedTo: {
              select: { id: true, name: true, avatar: true },
            },
            contact: {
              select: { id: true, firstName: true, lastName: true },
            },
          },
        }),
        prisma.lead.count({ where }),
      ]);

      return NextResponse.json({
        data: leads,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      });
    } catch (error) {
      console.error('Fetch leads error:', error);
      return NextResponse.json(
        { error: 'Leadler yüklenemedi' },
        { status: 500 }
      );
    }
  }
);

export const POST = withPermission('leads:create')(
  async (request: NextRequest, { session }) => {
    try {
      const body = await request.json();
      const data = leadSchema.parse(body);

      const lead = await prisma.lead.create({
        data: {
          ...data,
          tenantId: session.user.tenantId,
          createdById: session.user.id,
        },
      });

      // Audit log
      await createAuditLog({
        tenantId: session.user.tenantId,
        userId: session.user.id,
        action: 'CREATE',
        entityType: 'Lead',
        entityId: lead.id,
        description: `Lead oluşturuldu: ${data.name || data.phone}`,
      });

      return NextResponse.json(lead, { status: 201 });
    } catch (error) {
      console.error('Create lead error:', error);
      return NextResponse.json(
        { error: 'Lead oluşturulamadı' },
        { status: 500 }
      );
    }
  }
);
