// src/types/permissions.ts
import { UserRole } from '@prisma/client';

export type Permission =
  // Tenant
  | 'tenant:read'
  | 'tenant:update'
  // Users
  | 'users:list'
  | 'users:read'
  | 'users:create'
  | 'users:update'
  | 'users:delete'
  // Leads
  | 'leads:list'
  | 'leads:list:own'
  | 'leads:read'
  | 'leads:read:own'
  | 'leads:create'
  | 'leads:update'
  | 'leads:update:own'
  | 'leads:delete'
  | 'leads:assign'
  | 'leads:import'
  // Contacts
  | 'contacts:list'
  | 'contacts:read'
  | 'contacts:create'
  | 'contacts:update'
  | 'contacts:delete'
  | 'contacts:export'
  // Listings
  | 'listings:list'
  | 'listings:read'
  | 'listings:create'
  | 'listings:update'
  | 'listings:delete'
  | 'listings:publish'
  // Case Files
  | 'casefiles:list'
  | 'casefiles:list:own'
  | 'casefiles:read'
  | 'casefiles:read:own'
  | 'casefiles:read:assigned'
  | 'casefiles:create'
  | 'casefiles:update'
  | 'casefiles:update:own'
  | 'casefiles:delete'
  | 'casefiles:assign'
  // Activities
  | 'activities:list'
  | 'activities:list:own'
  | 'activities:read'
  | 'activities:create'
  | 'activities:update'
  | 'activities:update:own'
  | 'activities:delete'
  // Showings
  | 'showings:list'
  | 'showings:list:assigned'
  | 'showings:read'
  | 'showings:create'
  | 'showings:update'
  | 'showings:checkin'
  | 'showings:checkout'
  // Documents
  | 'documents:list'
  | 'documents:read'
  | 'documents:read:shared'
  | 'documents:upload'
  | 'documents:delete'
  // Contracts
  | 'contracts:list'
  | 'contracts:read'
  | 'contracts:create'
  | 'contracts:update'
  | 'contracts:delete'
  | 'contracts:templates'
  // Notifications
  | 'notifications:read'
  | 'notifications:update'
  // AI Features
  | 'ai:content'
  | 'ai:video'
  | 'ai:parcel'
  // Drone
  | 'drone:list'
  | 'drone:create'
  | 'drone:manage'
  // Integrations
  | 'integrations:read'
  | 'integrations:manage'
  | 'integrations:sync'
  | 'integrations:import'
  // Reports
  | 'reports:view'
  | 'reports:export'
  // Settings
  | 'settings:read'
  | 'settings:update'
  // Audit
  | 'audit:read'
  // KVKK
  | 'kvkk:read'
  | 'kvkk:manage'
  | 'kvkk:delete';

export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  ADMIN: [
    // Full access to everything
    'tenant:read', 'tenant:update',
    'users:list', 'users:read', 'users:create', 'users:update', 'users:delete',
    'leads:list', 'leads:list:own', 'leads:read', 'leads:read:own', 'leads:create', 'leads:update', 'leads:update:own', 'leads:delete', 'leads:assign', 'leads:import',
    'contacts:list', 'contacts:read', 'contacts:create', 'contacts:update', 'contacts:delete', 'contacts:export',
    'listings:list', 'listings:read', 'listings:create', 'listings:update', 'listings:delete', 'listings:publish',
    'casefiles:list', 'casefiles:list:own', 'casefiles:read', 'casefiles:read:own', 'casefiles:read:assigned', 'casefiles:create', 'casefiles:update', 'casefiles:update:own', 'casefiles:delete', 'casefiles:assign',
    'activities:list', 'activities:list:own', 'activities:read', 'activities:create', 'activities:update', 'activities:update:own', 'activities:delete',
    'showings:list', 'showings:list:assigned', 'showings:read', 'showings:create', 'showings:update', 'showings:checkin', 'showings:checkout',
    'documents:list', 'documents:read', 'documents:read:shared', 'documents:upload', 'documents:delete',
    'contracts:list', 'contracts:read', 'contracts:create', 'contracts:update', 'contracts:delete', 'contracts:templates',
    'notifications:read', 'notifications:update',
    'ai:content', 'ai:video', 'ai:parcel',
    'drone:list', 'drone:create', 'drone:manage',
    'integrations:read', 'integrations:manage', 'integrations:sync', 'integrations:import',
    'reports:view', 'reports:export',
    'settings:read', 'settings:update',
    'audit:read',
    'kvkk:read', 'kvkk:manage', 'kvkk:delete',
  ],
  
  SECRETARY: [
    'tenant:read',
    'users:list', 'users:read',
    'leads:list', 'leads:read', 'leads:create', 'leads:update', 'leads:assign', 'leads:import',
    'contacts:list', 'contacts:read', 'contacts:create', 'contacts:update', 'contacts:export',
    'listings:list', 'listings:read', 'listings:create', 'listings:update', 'listings:publish',
    'casefiles:list', 'casefiles:read', 'casefiles:create', 'casefiles:update', 'casefiles:assign',
    'activities:list', 'activities:read', 'activities:create', 'activities:update',
    'showings:list', 'showings:read', 'showings:create', 'showings:update',
    'documents:list', 'documents:read', 'documents:upload',
    'contracts:list', 'contracts:read', 'contracts:create', 'contracts:update', 'contracts:templates',
    'notifications:read', 'notifications:update',
    'ai:content',
    'drone:list', 'drone:create',
    'integrations:read', 'integrations:sync', 'integrations:import',
    'reports:view',
    'settings:read',
  ],
  
  AGENT: [
    'tenant:read',
    'leads:list:own', 'leads:read:own', 'leads:create', 'leads:update:own',
    'contacts:list', 'contacts:read', 'contacts:create', 'contacts:update',
    'listings:list', 'listings:read', 'listings:create', 'listings:update',
    'casefiles:list:own', 'casefiles:read:own', 'casefiles:create', 'casefiles:update:own',
    'activities:list:own', 'activities:read', 'activities:create', 'activities:update:own',
    'showings:list', 'showings:read', 'showings:create', 'showings:update', 'showings:checkin', 'showings:checkout',
    'documents:list', 'documents:read', 'documents:upload',
    'contracts:list', 'contracts:read', 'contracts:create',
    'notifications:read', 'notifications:update',
    'ai:content', 'ai:video',
    'drone:list', 'drone:create',
    'reports:view',
  ],
  
  FIELD: [
    'tenant:read',
    'listings:list', 'listings:read',
    'showings:list:assigned', 'showings:read', 'showings:checkin', 'showings:checkout',
    'documents:upload',
    'notifications:read', 'notifications:update',
  ],
  
  CLIENT: [
    'casefiles:list:own', 'casefiles:read:own',
    'documents:read:shared',
    'notifications:read', 'notifications:update',
  ],
};

export function hasPermission(role: UserRole, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
}

export function hasAnyPermission(role: UserRole, permissions: Permission[]): boolean {
  return permissions.some((p) => hasPermission(role, p));
}

export function hasAllPermissions(role: UserRole, permissions: Permission[]): boolean {
  return permissions.every((p) => hasPermission(role, p));
}
